package com.malkit.jmstest;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.l2fprod.common.demo.TaskPaneMain;
import com.l2fprod.common.swing.JTaskPaneGroup;

class CollapsibleWorkbenchPane extends JPanel {
    private static final long serialVersionUID = 1L;

    JPanel taskPane = null;

    List groupList = new ArrayList();

    List clientViewList = new ArrayList();

    private MainPanel mainPanel = null;

    public CollapsibleWorkbenchPane(MainPanel mainPanel) {
        this.mainPanel = mainPanel;

        taskPane = new JPanel();
        taskPane.setLayout(new GridBagLayout());

        JScrollPane scroll = new JScrollPane(taskPane);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.setBorder(null);

        setLayout(new BorderLayout());
        add(scroll);
        setBorder(null);
    }

    public void addGroupPanel(JMSClient first, JMSClient second, Properties prop) {
        String label = first.getName() + " | " + second.getName();
        String image = null;

        String firstType = first.getType();
        String secondType = second.getType();

        if (firstType.equals(MainPanel.QUEUE) && secondType.equals(MainPanel.QUEUE)) {
            image = "icons/queue_queue.png";
        } else if (firstType.equals(MainPanel.QUEUE) && secondType.equals(MainPanel.TOPIC)) {
            image = "icons/queue_topic.png";
        } else if (firstType.equals(MainPanel.TOPIC) && secondType.equals(MainPanel.TOPIC)) {
            image = "icons/topic_topic.png";
        } else {
            image = "icons/topic_queue.png";
        }

        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weightx = 1;
        c.weighty = 0;
        c.insets = new Insets(4, 0, 0, 0);

        JTaskPaneGroup group = getTaskPaneGroup(label, image, first, second, prop);
        groupList.add(group);
        taskPane.add(group, c);

    }

    private JTaskPaneGroup getTaskPaneGroup(String label,
                                            String image,
                                            JMSClient first,
                                            JMSClient second,
                                            Properties prop) {
        JTaskPaneGroup group = new JTaskPaneGroup();
        group.setTitle(label);
        group.setToolTipText(label);
        // group.setSpecial(true);
        group.setIcon(new ImageIcon(TaskPaneMain.class.getResource(image)));
        group.setExpanded(true);
        group.add(createInputOutputGroup(first, second, prop));
        return group;
    }

    /**
     * @param first JMSTestClinet
     * @param second JMSTestClient
     * @return JComponent
     */
    private JComponent createInputOutputGroup(JMSClient first, JMSClient second, Properties prop) {

        JMSClientView firstView = new JMSClientView(mainPanel, first, prop);
        JMSClientView secondView = new JMSClientView(mainPanel, second, prop);

        JComponent panel = new JPanel();
        //panel.setPreferredSize(new Dimension(170, 196));
        panel.setLayout(new GridBagLayout());
        
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.weighty = 1;
        
        panel.add(firstView, c);
        c.gridwidth = GridBagConstraints.REMAINDER;
        panel.add(secondView, c);
        clientViewList.add(firstView);
        clientViewList.add(secondView);

        return panel;
    }

    public void reset() {
        if (clientViewList != null) {
            for (int i = 0; i < clientViewList.size(); i++) {
                JMSClientView client = (JMSClientView) clientViewList.get(i);
                client.stopClient();
            }
            clientViewList = new ArrayList();
        }
        if (groupList != null) {
            for (int i = 0; i < groupList.size(); i++) {
                taskPane.remove((JTaskPaneGroup) groupList.get(i));
            }
            groupList = new ArrayList();
        }
    }
}