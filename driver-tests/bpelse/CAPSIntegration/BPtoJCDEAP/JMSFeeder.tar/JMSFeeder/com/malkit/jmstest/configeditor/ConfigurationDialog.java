package com.malkit.jmstest.configeditor;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.malkit.jmstest.JMSClient;
import com.malkit.jmstest.MainPanel;


public class ConfigurationDialog extends JDialog {

	private static final long serialVersionUID = 1L;
	
	final List jmsClientlist = new ArrayList();
	final Properties connectionProp = new Properties();
	
	//CollapsibleConfigurationPane collapsiblePane = null;
	OutlookTypeConfigurationPane collapsiblePane = null;
	
	int groupIDCount;
    
    JComboBox tfJMSServer = null;
    
	JTextField tfHost = null;
	JTextField tfPort = null;
	JTextField tfLogin = null;
	JTextField tfPassword = null;
	
	/**
	 * @param frame
	 * @param prop
	 * @param configList
	 */
	public ConfigurationDialog(JFrame frame, Properties prop, List configList) {
		
		super(frame);
		
		setSize(500, 404);
		setLocationRelativeTo(frame);
		setResizable(false);
		setModal(true);
		setTitle("Properties Configuration");
		
		JPanel cPane = new JPanel();
		cPane.setLayout(new GridBagLayout());
		
		GridBagConstraints c = new GridBagConstraints();

		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;

		c.weightx = 1;
		c.weighty = 0;
		c.insets = new Insets(0,5,0,5);

		cPane.add(getGeneralPropertiesPanel(prop), c);
		
		//.anchor = GridBagConstraints.NORTHWEST;
		c.insets = new Insets(5,10,5,10);
		c.fill = GridBagConstraints.BOTH;
		c.weighty = 1;
		initCollapsiblePane(configList);
		cPane.add(collapsiblePane, c);

		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.WEST;
		c.gridwidth = 1;
		c.weighty = 0;
		c.insets = new Insets(5, 5, 5, 5);
		cPane.add(getAddNewButton(), c);
		//cPane.add(getRemoveButton(), c);

		c.weightx = 0;
		cPane.add(getOKButton(), c);
		cPane.add(getCancelButton(), c);
		
		getContentPane().add(cPane);
		setVisible(true);
	}

	public Properties getConnectionProperties() {
		return connectionProp;
	}
	
	public List getTestClientConfigurations() {
		return jmsClientlist;
	}

	private void initCollapsiblePane(List configList) {
		this.groupIDCount = 1;
		
		if(collapsiblePane == null) {
			collapsiblePane = new OutlookTypeConfigurationPane();
		}
		
		Configuration configLeft = null;
		Configuration configRight = null;
		
		if(configList != null && configList.size() > 0) {
			for(int i = 0; i < configList.size(); i++) {
				configLeft = new Configuration((JMSClient)configList.get(i), null);
				configLeft.initialize();
				
				configRight = new Configuration((JMSClient)configList.get(++i), null);
				configRight.initialize();

				collapsiblePane.addGroupPanel(configLeft, configRight);
				groupIDCount ++;
			}
		} else {
			List list = getNewConfigurationGroup(groupIDCount);
			collapsiblePane.addGroupPanel((Configuration)list.get(0), (Configuration)list.get(1));
		}
	}
	
	private JPanel getGeneralPropertiesPanel(Properties prop) {
		JPanel pane = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.CENTER;
        c.fill = GridBagConstraints.NONE;

        c.weightx = 1;
        c.weighty = 1;
        
        pane.add(getServerDetailsPanel(prop));
		pane.add(getHostDetailsPanel(prop));
		c.gridwidth = GridBagConstraints.REMAINDER;
		pane.add(getLoginInfoPanel(prop));
		return pane;
	}
	
	private JPanel getServerDetailsPanel(Properties prop) {
		JPanel pane = new JPanel();

        String[] servers = {MainPanel.JAVA_MQ_3_7, MainPanel.STC_JMS_5_1};
        String server = prop.getProperty(MainPanel.SERVER) == null ? MainPanel.JAVA_MQ_3_7 : (String)prop.getProperty(MainPanel.SERVER);
        tfJMSServer = new JComboBox(servers);
        tfJMSServer.setSelectedItem(server);
		pane.setLayout(new GridBagLayout());
		pane.setBorder(BorderFactory.createCompoundBorder(BorderFactory
				.createTitledBorder(" JMS Server "), BorderFactory.createEmptyBorder(2, 2, 2, 2)));
        pane.add(tfJMSServer);
		return pane;
	}
	
    private JPanel getHostDetailsPanel(Properties prop) {
        JPanel pane = new JPanel();

        String server = prop.getProperty(MainPanel.HOST) == null ? "localhost" : (String)prop.getProperty(MainPanel.HOST);
        tfHost = new JTextField(server, 12);
        
        String port = prop.getProperty(MainPanel.PORT) == null ? "18007" : (String)prop.getProperty(MainPanel.PORT);
        tfPort = new JTextField(port, 12);
        
        JLabel lServer = new JLabel("Name :");
        lServer.setLabelFor(tfHost);

        JLabel lPort = new JLabel("Port :");
        lPort.setLabelFor(tfPort);
        
        pane.setLayout(new GridBagLayout());
        pane.setBorder(BorderFactory.createCompoundBorder(BorderFactory
                .createTitledBorder(" Host "), BorderFactory.createEmptyBorder(2, 2, 2, 2)));

        GridBagLayout gridbag = new GridBagLayout();

        JLabel[] labels = {lServer, lPort};
        JComponent[] textFields = {tfHost, tfPort};
        addLabelTextRows(labels, textFields, gridbag, pane);
        
        return pane;
    }
    
	private JPanel getLoginInfoPanel(Properties prop) {
		JPanel pane = new JPanel();

		String login = prop.getProperty(MainPanel.LOGIN) == null ? "Administrator" : (String)prop.getProperty(MainPanel.LOGIN);
		tfLogin = new JTextField(login, 12);
		
		String password = prop.getProperty(MainPanel.PASSWORD) == null ? "STC" : (String)prop.getProperty(MainPanel.PASSWORD);
		tfPassword = new JTextField(password, 12);
		JLabel lLogin = new JLabel("User :");
		lLogin.setLabelFor(tfLogin);
		
		JLabel lPassword = new JLabel("Password :");
		lPassword.setLabelFor(tfPassword);
		
		pane.setLayout(new GridBagLayout());
		pane.setBorder(BorderFactory.createCompoundBorder(BorderFactory
				.createTitledBorder(" Login "), BorderFactory.createEmptyBorder(2, 2, 2, 2)));

		GridBagLayout gridbag = new GridBagLayout();

		JLabel[] labels = {lLogin, lPassword};
		JComponent[] textFields = {tfLogin, tfPassword};
		addLabelTextRows(labels, textFields, gridbag, pane);
		
		return pane;
	}
	
	private void addLabelTextRows(	JLabel[] labels,
									JComponent[] textFields,
									GridBagLayout gridbag,
									JPanel panel) {
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.WEST;
		int numLabels = labels.length;

		for (int i = 0; i < numLabels; i++) {
			c.gridwidth = GridBagConstraints.RELATIVE; // next-to-last
			c.fill = GridBagConstraints.NONE; // reset to default
			c.weightx = 1.0; // reset to default
			c.weighty = 1;
			panel.add(labels[i], c);

			c.gridwidth = GridBagConstraints.REMAINDER; // end row
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0.0;
			panel.add(textFields[i], c);
		}
	}
	
	private JButton getAddNewButton() {
		JButton jbAddNew = new JButton("Add New");

		jbAddNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				List list = getNewConfigurationGroup(groupIDCount++);
				collapsiblePane.addGroupPanel((Configuration)list.get(0), (Configuration)list.get(1));
				
				collapsiblePane.revalidate();
				repaint();
			}
		});
		return jbAddNew;
	}
	
	private JButton getRemoveButton() {
		JButton jbRemove = new JButton("Remove");
		
		jbRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				collapsiblePane.removeTab();
			}
		});
		return jbRemove;
	}

	private List getNewConfigurationGroup(int groupIDCount) {
		List list = new ArrayList();
		
		Configuration config1 = new Configuration(null, "Queue1");
		config1.setType(MainPanel.QUEUE);
		config1.setSubType(MainPanel.PRODUCER);
		config1.setGroupId(new Integer(groupIDCount).toString());
		list.add(config1);
		
		Configuration config2 = new Configuration(null, "Queue2");
		config2.setType(MainPanel.QUEUE);
		config2.setSubType(MainPanel.CONSUMER);
		config2.setGroupId(new Integer(groupIDCount).toString());
		list.add(config2);
		
		return list;
	}
	
	private JButton getOKButton() {
		JButton jbOk = new JButton("  Ok  ");

		jbOk.setToolTipText("Save Properties");

		jbOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

			    connectionProp.put(MainPanel.SERVER, (String) tfJMSServer.getSelectedItem());
				connectionProp.put(MainPanel.HOST, tfHost.getText());
				connectionProp.put(MainPanel.PORT, tfPort.getText());
				connectionProp.put(MainPanel.LOGIN, tfLogin.getText());
				connectionProp.put(MainPanel.PASSWORD, tfPassword.getText());
				
				List confLiist = collapsiblePane.getConfigurationList();
				
				if(confLiist != null && confLiist.size() > 0) {
					for(int i = 0; i < confLiist.size(); i++) {
						Configuration configLeft = (Configuration)confLiist.get(i);
						
						JMSClient client1 = new JMSClient(configLeft.getName(), configLeft.getCount(),
								configLeft.getType(), configLeft.getSubType(), configLeft.getInputFile());
						client1.setGroupid(configLeft.getGroupId());
						client1.setLogging(configLeft.getLogging());
						client1.setMessagePropertyList(configLeft.getMessageProperties());
						
						Configuration configRight = (Configuration)confLiist.get(++i);
						JMSClient client2 = new JMSClient(configRight.getName(), configRight.getCount(),
								configRight.getType(), configRight.getSubType(), configRight.getInputFile());
						client2.setGroupid(configRight.getGroupId());
						client2.setLogging(configRight.getLogging());
						client2.setMessagePropertyList(configRight.getMessageProperties());
						
						jmsClientlist.add(client1);
						jmsClientlist.add(client2);
					}
				}
				
				saveConfigFile(connectionProp, jmsClientlist);
				dispose();
			}
		});

		return jbOk;
	}
	
	protected void saveConfigFile(Properties prop, List jmsClientlist) {
		Parser.writeFile(prop, jmsClientlist);
	}

	private JButton getCancelButton() {
		JButton jbCancel = new JButton("Cancel");
		
		jbCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();

			}
		});
		return jbCancel;
	}
}