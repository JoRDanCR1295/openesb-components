package com.malkit.jmstest.configeditor;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.malkit.jmstest.JMSClient;
import com.malkit.jmstest.MessageProperty;

public class MsgPropertiesDialog extends JDialog {

    private static final String LABEL_START_INDEX = "Start Index";

    private static final String DEFAULT_PROP_NAME = "property";

    private static final String DEFAULT_PROP_VALUE = "value";

    private static final boolean DEFAULT_BOOLEAN_VALUE = Boolean.TRUE;
    private static final byte DEFAULT_BYTE_VALUE = Byte.MIN_VALUE;
    private static final int DEFAULT_INT_VALUE = Integer.MIN_VALUE;
    private static final long DEFAULT_LONG_VALUE = Long.MIN_VALUE;
    private static final float DEFAULT_FLOAT_VALUE = Float.MIN_VALUE;
    private static final double DEFAULT_DOUBLE_VALUE = Double.MIN_VALUE;

    private static final String DEFAULT_AUTO_INCREMENT_VALUE = "1";

    private JComboBox cbPropertyType = null;

    private JTextField tfPropertyName = null;

    private JTextField tfValue = null;

    private List messagePropertiesList = new ArrayList();

    JPanel cPane = null;

    public MsgPropertiesDialog(JPanel parent, JMSClient jmsClient) {
        // super(frame);
        setSize(400, 200);
        setLocationRelativeTo(parent);
        setResizable(false);
        setModal(true);
        setTitle("Message Properties Configuration");
        cPane = new JPanel();
        // cPane.setLayout(new GridBagLayout());
        cPane.setLayout(new GridBagLayout());
        cPane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("JMS Message Properties"),
                BorderFactory.createEmptyBorder(1, 1, 1, 1)));

        final JLabel lId = new JLabel(MessageProperty.LABEL_NAME);
        final JLabel lType = new JLabel(MessageProperty.LABEL_TYPE);
        final JLabel lValue = new JLabel(MessageProperty.LABEL_VALUE);

        this.cbPropertyType = new JComboBox(MessageProperty.PROPERTY_TYPES);

        if (jmsClient != null && jmsClient.getMessagePropertyList() != null
                && (jmsClient.getMessagePropertyList().size() > 0)) {
            List messagePropertyList = jmsClient.getMessagePropertyList();
            // currnently only one property is implemetned.
            MessageProperty messageProperty = (MessageProperty) messagePropertyList.get(0);
            this.tfPropertyName = new JTextField(messageProperty.getName(), 8);
            this.cbPropertyType.setSelectedItem(messageProperty.getType());
            this.tfValue = new JTextField(messageProperty.getValue(), 15);
        } else {
            this.tfPropertyName = new JTextField(DEFAULT_PROP_NAME, 8);
            this.tfValue = new JTextField(DEFAULT_PROP_VALUE, 15);
            this.cbPropertyType = new JComboBox(MessageProperty.PROPERTY_TYPES);
        }

        cbPropertyType.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                lType.setText(MessageProperty.LABEL_VALUE);
                String selectedItem = (String) cbPropertyType.getSelectedItem();

                if (selectedItem.equals(MessageProperty.STRING)) {
                    tfValue.setText(DEFAULT_PROP_VALUE);
                    tfValue.setEditable(true);
                } else if (selectedItem.equals(MessageProperty.BOOLEAN)) {
                    tfValue.setText(DEFAULT_BOOLEAN_VALUE + "");
                    tfValue.setEditable(true);
                } else if (selectedItem.equals(MessageProperty.BYTE)) {
                    tfValue.setText(DEFAULT_BYTE_VALUE + "");
                    tfValue.setEditable(true);
                } else if (selectedItem.equals(MessageProperty.INT)) {
                    tfValue.setText(DEFAULT_INT_VALUE + "");
                    tfValue.setEditable(true);
                } else if (selectedItem.equals(MessageProperty.LONG)) {
                    tfValue.setText(DEFAULT_LONG_VALUE + "");
                    tfValue.setEditable(true);
                } else if (selectedItem.equals(MessageProperty.FLOAT)) {
                    tfValue.setText(DEFAULT_FLOAT_VALUE + "");
                    tfValue.setEditable(true);
                } else if (selectedItem.equals(MessageProperty.DOUBLE)) {
                    tfValue.setText(DEFAULT_DOUBLE_VALUE + "");
                    tfValue.setEditable(true);
                }  else if (selectedItem.equals(MessageProperty.GUID)) {
                    tfValue.setText("<GUID>");
                    tfValue.setEditable(false);
                } else if (selectedItem.equals(MessageProperty.AUTO_INCREMENT)) {
                    tfValue.setText(DEFAULT_AUTO_INCREMENT_VALUE);
                    tfValue.setEditable(true);
                }
            }
        });

        lId.setLabelFor(tfPropertyName);
        lValue.setLabelFor(tfValue);

        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.EAST;
        // c.gridwidth = GridBagConstraints.RELATIVE;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = .5;
        c.weighty = 0;
        c.gridx = 0;
        c.gridy = 0;
        cPane.add(lId, c);

        c.gridx = 1;
        c.gridy = 0;
        cPane.add(lType, c);

        c.gridx = 2;
        c.gridy = 0;
        cPane.add(lValue, c);

        c.gridx = 0;
        c.gridy = 1;
        cPane.add(tfPropertyName, c);

        c.gridx = 1;
        c.gridy = 1;
        cPane.add(cbPropertyType, c);

        c.gridx = 2;
        c.gridy = 1;
        cPane.add(tfValue, c);

        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.EAST;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        cPane.add(getOKButton(), c);
        c.gridx = 1;
        c.gridy = 2;
        cPane.add(getCancelButton(), c);
        c.weightx = 0;
        c.gridx = 2;
        c.gridy = 2;
        cPane.add(getResetToDefaultButton(), c);

        getContentPane().add(cPane);

        setVisible(true);
    }

    public List getMessageProperties() {
        return messagePropertiesList;
    }

    private JButton getResetToDefaultButton() {
        JButton jbCancel = new JButton("Reset To Default");

        jbCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                messagePropertiesList = null;
                dispose();
            }
        });
        return jbCancel;
    }
    
    private JButton getOKButton() {
        JButton jbOk = new JButton("  Ok  ");

        jbOk.setToolTipText("Save Properties");
        jbOk.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (tfPropertyName.getText().equals("")) {
                    JOptionPane.showMessageDialog(cPane, "The property id not specified\nPlease enter id value");
                    tfValue.setText("");
                    return;
                }
                if (cbPropertyType.getSelectedItem().equals(MessageProperty.AUTO_INCREMENT)) {
                    try {
                        if (tfValue.getText() != null && !tfValue.getText().equals("")) {
                            Long.valueOf(tfValue.getText());
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(cPane, "The selected property type is "
                                + MessageProperty.AUTO_INCREMENT
                                + " Auto-Increment\nPlease enter valid non-negative integer value");
                        tfValue.setText("");
                        return;
                    }
                } else if (cbPropertyType.getSelectedItem().equals(MessageProperty.STRING)) {
                    if (tfValue.getText().equals("")) {
                        JOptionPane.showMessageDialog(cPane,
                                "The property name is not specified\nPlease enter name for the property");
                        return;
                    }
                }

                MessageProperty messageProperty = new MessageProperty(tfPropertyName.getText(), (String) cbPropertyType.getSelectedItem(), tfValue.getText());
                messagePropertiesList.add(messageProperty);
                dispose();
            }
        });

        return jbOk;
    }

    private JButton getCancelButton() {
        JButton jbCancel = new JButton("Cancel");

        jbCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        return jbCancel;
    }
}
