package com.malkit.jmstest.configeditor;

import java.awt.Color;
import java.io.File;

import javax.swing.JLabel;
import javax.swing.UIManager;

class EditorLabel extends JLabel {


	private static final long serialVersionUID = 1L;

	public EditorLabel(String p) {

		setText(p.toString());
		File f = new File(p.toString());
		if (p.toString().equals(""))
			setText("(edit)");
		else if (!f.exists()) {
			setForeground(Color.red);
			setText(getText() + " (invalid)");
		}
		setIcon(UIManager.getIcon("FileView.fileIcon"));
	}

	public void setText(String s) {
		if (s.length() > 40) {
			String stretchText =
				s.substring(0, 8) + " ... " + s.substring(s.length() - 8);
			super.setText(stretchText);
		} else {
			super.setText(s);
		}
	}
}