package com.malkit.jmstest.configeditor;

/*
 * Copyright Sun Microsystems, Inc. All rights reserved. Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following conditions are met: - Redistributions of source code
 * must retain the above copyright notice, this list of conditions and the following disclaimer. - Redistribution in
 * binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution. Neither the name of Sun Microsystems, Inc. or
 * the names of contributors may be used to endorse or promote products derived from this software without specific
 * prior written permission. This software is provided "AS IS," without a warranty of any kind. ALL EXPRESS OR IMPLIED
 * CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO
 * EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
 * CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT
 * OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. You
 * acknowledge that Software is not designed, licensed or intended for use in the design, construction, operation or
 * maintenance of any nuclear facility.
 */
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.malkit.jmstest.JMSClient;
import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.MessageProperty;

/**
 * This class construcs an XML document in memory using DOM. It first creates the root Order element and subsequently
 * creates components of the order by inserting nodes to the root element.
 */
public class CreateConfigurationDOM {

    /**
     * DOM Document
     */
    private Document document = null;

    public CreateConfigurationDOM(Properties prop, List jmsClientList) {
        DocumentBuilder builder = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            builder = factory.newDocumentBuilder();
            document = builder.newDocument();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        // Insert Root Order
        Element root = (Element) document.createElement("properties");
        // Insert child Manifest
        document.appendChild(root);

        Node general = createGeneralProperties(document, prop);

        root.appendChild(general);
        int groupid = 1;

        if (jmsClientList != null) {
            for (int i = 0; i < jmsClientList.size(); i++) {
                Node groupChild = document.createElement("group");
                root.appendChild(groupChild);
                Node id = document.createAttribute("id");

                JMSClient client = (JMSClient) jmsClientList.get(i);
                // id.setNodeValue(client.getGroupid());
                id.setNodeValue(new Integer(groupid++).toString());
                groupChild.getAttributes().setNamedItem(id);
                insertClient(document, groupChild, client);

                client = (JMSClient) jmsClientList.get(++i);
                insertClient(document, groupChild, client);
            }
        }

        // Normalizing the DOM
        document.getDocumentElement().normalize();
    }

    /**
     * @return Document
     */
    public Document getDocument() {
        return document;
    }

    private Node createGeneralProperties(Document document, Properties prop) {
        Node general = document.createElement(MainPanel.CONNECTIONPROPERTIES);

        Node server = document.createElement(MainPanel.SERVER);
        general.appendChild(server);
        Node value = document.createTextNode(prop.getProperty(MainPanel.SERVER));
        server.appendChild(value);

        Node host = document.createElement(MainPanel.HOST);
        general.appendChild(host);
        value = document.createTextNode(prop.getProperty(MainPanel.HOST));
        host.appendChild(value);

        Node port = document.createElement(MainPanel.PORT);
        general.appendChild(port);
        value = document.createTextNode(prop.getProperty(MainPanel.PORT));
        port.appendChild(value);

        Node login = document.createElement(MainPanel.LOGIN);
        general.appendChild(login);
        value = document.createTextNode(prop.getProperty(MainPanel.LOGIN));
        login.appendChild(value);

        Node password = document.createElement(MainPanel.PASSWORD);
        general.appendChild(password);
        value = document.createTextNode(prop.getProperty(MainPanel.PASSWORD));
        password.appendChild(value);
        return general;
    }

    private void insertClient(Document document, Node groupChild, JMSClient client) {
        // Insert Items
        insertItem(document, groupChild, client.getName(), client.getType(), client.getSubType(),
                client.getSendCount(), client.getInputfile(), client.getLogging(), client.getMessagePropertyList());
    }

    /**
     * Insert "Item" to Document
     * 
     * @param document - Order Document
     * @param parent - Node where to insert a "Item"
     * @param name - Item's ID
     * @param name - Item's Name
     * @param subType - Item's Price
     */
    private void insertItem(Document document,
                            Node parent,
                            String name,
                            String type,
                            String subType,
                            String count,
                            String inputFile,
                            String logging,
                            List messageProperties) {
        // Insert child testunit
        Node testunit = document.createElement("testunit");
        parent.appendChild(testunit);

        // Insert child name
        Node child = document.createElement("name");
        testunit.appendChild(child);
        // Insert name value
        Node value = document.createTextNode(name);
        child.appendChild(value);

        // Insert child type
        child = document.createElement("type");
        testunit.appendChild(child);
        // Insert type value
        value = document.createTextNode(type);
        child.appendChild(value);

        // Insert child subtype
        child = document.createElement("subtype");
        testunit.appendChild(child);
        // Insert subtype value
        value = document.createTextNode(subType);
        child.appendChild(value);

        // Insert child count
        child = document.createElement("count");
        testunit.appendChild(child);
        // Insert count value
        value = document.createTextNode(count);
        child.appendChild(value);

        // Insert child inputfile
        child = document.createElement("inputfile");
        testunit.appendChild(child);
        // Insert inputfile value
        value = document.createTextNode(inputFile);
        child.appendChild(value);

        // Insert child progressBar
        child = document.createElement("logging");
        testunit.appendChild(child);

        // Insert progressBar value
        value = document.createTextNode(logging);
        child.appendChild(value);

        // Insert properties
        child = document.createElement(MainPanel.MESSAGE_PROPERTIES);
        testunit.appendChild(child);

        Node property = null;
        Node propertyName = null;
        Node propertyType = null;
        Node propertyValue = null;
        
        if (messageProperties != null && messageProperties.size() > 0) {
            for (int i = 0; i < messageProperties.size(); i++) {
                MessageProperty messageProperty = (MessageProperty) messageProperties.get(i);
                // Insert properties
                property = document.createElement("property");
                child.appendChild(property);
                
                propertyName = document.createAttribute(MessageProperty.LABEL_NAME);
                propertyName.setNodeValue(messageProperty.getName());
                property.getAttributes().setNamedItem(propertyName);
                
                propertyType = document.createAttribute(MessageProperty.LABEL_TYPE);
                propertyType.setNodeValue(messageProperty.getType());
                property.getAttributes().setNamedItem(propertyType);
                
                propertyValue = document.createAttribute(MessageProperty.LABEL_VALUE);
                propertyValue.setNodeValue(messageProperty.getValue());
                property.getAttributes().setNamedItem(propertyValue);            
            }
        }
    }
}
