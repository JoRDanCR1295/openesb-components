package com.malkit.jmstest.testclient.topic;

import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;

import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.testclient.TestClient;
import com.stc.jms.client.STCTopicConnectionFactory;

public class TopicTestClient extends TestClient {
    
    String server = null;
    TopicConnectionFactory fact = null;
    TopicConnection con = null;
    
    public TopicTestClient(Properties prop) throws NumberFormatException, JMSException {
        super(prop);
        this.server = new String(prop.getProperty(MainPanel.SERVER));
        fact = new STCTopicConnectionFactory(host, new Integer(port).intValue());
        con = fact.createTopicConnection(login, password);
    }
}
