package com.malkit.jmstest;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;

import com.l2fprod.common.demo.TaskPaneMain;
import com.malkit.jmstest.testclient.queue.QReceiver;
import com.malkit.jmstest.testclient.queue.QSender;
import com.malkit.jmstest.testclient.topic.PublishTopic;
import com.malkit.jmstest.testclient.topic.SubscribeTopic;

/**
 * JMSTest Client class.
 * 
 * @author mbhasin
 */

public class JMSClientView extends JPanel {

    public static final int LOGGING_LEVEL_INFO = 1;

    public static final int LOGGING_LEVEL_CONNECTION_STATUS = 2;

    public static final int LOGGING_LEVEL_ERROR = 3;

    public static final int LOGGING_LEVEL_BENCHMARK = 4;

    private static final long serialVersionUID = 1L;
    
    private static DecimalFormat formatter = new DecimalFormat ( "#.##"); 

    private JProgressBar progressBar;

    private Timer timer;

    private Timer timerBenchmarking;

    private JButton bStart;

    private JButton bStop;

    private JTextArea taInput;

    private JTextArea taOutput;

    private JTabbedPane tabbedPane = null;

    private JTextField tfRefresh = null;

    private JComboBox cbRefresh = null;

    private int current = 0;

    private int modulusCounter = 0;

    private String statMessage;

    private boolean done = false;

    private int lengthOfTask;

    private MainPanel mainPanel;

    private QReceiver qConsr = null;

    private QSender qProdr = null;

    private PublishTopic topicPub = null;

    private SubscribeTopic topicsub = null;

    private boolean canceled = false;

    private JMSTask worker = null;

    private static final int BENCHMARKING = 1;

    private static final int MINIMUM = 2;

    private static final int MAXIMUM = 3;

    private int clientLoggingLevel;

    private JMSClient client = null;

    private boolean flagWriteOutoutForBenchmark = true;
    
    private int receiveCountForBenchmarking;

    /*Following parametes for bencmarking*/
    private float lastElapsedTime = 0;
    private float lastCount = -1;
    private int refreshInterval;
    
    
    /**
     * @param panel MainPanel
     * @param ct JMSClient
     * @param prop Properties
     */
    public JMSClientView(MainPanel panel, JMSClient ct, Properties prop) {

        this.mainPanel = panel;
        this.clientLoggingLevel = MAXIMUM;
        this.client = ct;

        setBorder(BorderFactory.createTitledBorder(" " + client.getType() + " " + client.getSubType() + " : "
                + client.getName()));

        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.CENTER;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weightx = 1;
        c.weighty = 0;
        //c.insets = new Insets(1, 1, 1, 1);
        add(getToolBarPanel(prop), c);

        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1;
        add(getTabbedPane(), c);
    }

    /**
     * To get the tool bar panel.
     * 
     * @param prop Properties
     * @return JPanel
     */
    private JPanel getToolBarPanel(Properties prop) {
        timer = getTimer(client.getSubType());

        String subType = client.getSubType();

        JLabel lsendCount = new JLabel(MainPanel.COUNT);
        
        lsendCount.setText("<html><B>To Send: " + client.getSendCount() + "</html></B>");
        //lsendCount.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
        
        JPanel pane = new JPanel();
        //Border paneEdge = BorderFactory.createEmptyBorder(1,1,1,1);
        //pane.setBorder(paneEdge);
        
        pane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.EAST;
        c.fill = GridBagConstraints.NONE;

        
        c.weightx = 0;
        if (subType.equals(MainPanel.PRODUCER) || subType.equals(MainPanel.PUBLISHER)) {
            pane.add(lsendCount, c);
        } else {
            pane.add(new JLabel(""), c);
        }
        
        c.weightx = 1;
        pane.add(new JLabel(""), c);
        c.weightx = 0;
        pane.add(getSeperator(), c);
        pane.add(getStartButton(prop), c);
        pane.add(getStopButton(), c);
        pane.add(getSeperator(), c);
        c.gridwidth = GridBagConstraints.REMAINDER; // end row
        pane.add(getProgressBar(client.getSendCount()), c);
        //resetProgressBar();
        return pane;
    }

    /**
     * To get the seperator.
     * 
     * @return JLabel
     */
    private JLabel getSeperator() {
        JLabel lSeperator = new JLabel(new ImageIcon(TaskPaneMain.class.getResource("icons/seperator.png")));
        return lSeperator;
    }

    /**
     * To get the start button.
     * 
     * @param prop Properties
     * @return JButton
     */
    private JButton getStartButton(final Properties prop) {
        bStart = new JButton();
        bStart.setPreferredSize(new Dimension(50, 24));
        bStart.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                worker = new JMSTask(prop);
                worker.start();
            }
        });

        if (client.getType().equals(MainPanel.QUEUE)) {
            bStart.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/start_queue.png")));
        } else {
            bStart.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/start_topic.png")));
        }
        bStart.setActionCommand(client.getName());
        bStart.setEnabled(true);
        return bStart;
    }

    /**
     * To get the stop button.
     * 
     * @return JButton
     */
    private JButton getStopButton() {
        bStop = new JButton();
        bStop.setPreferredSize(new Dimension(24, 24));
        bStop.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                stopClient();
            }
        });
        bStop.setActionCommand(MainPanel.STOP);
        bStop.setEnabled(false);
        bStop.setBorder(BorderFactory.createEmptyBorder(0, 3, 0, 3));
        bStop.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/terminate_co.png")));
        bStop.setEnabled(false);
        return bStop;
    }

    /**
     * Get the tabbed pane.
     * 
     * @return JPanel
     */
    private JPanel getTabbedPane() {
        String subType = client.getSubType();

        JPanel pane = new JPanel();
        //pane.setPreferredSize(new Dimension(350, 100));
        
        pane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.EAST;
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER; // end row
        c.weighty = 1;

        JPanel output = getOutputAreaPanel();

        if (subType.equals(MainPanel.PRODUCER) || subType.equals(MainPanel.PUBLISHER)) {
            tabbedPane = new JTabbedPane();
            tabbedPane.setPreferredSize(new Dimension(370, 160));
            String inputFile = client.getInputfile();

            tabbedPane.addTab(" Input Data ", getInputAreaPanel(inputFile));
            tabbedPane.addTab(" Message Properties ", getMessagePropertiesPanel());
            tabbedPane.addTab(" Output Log ", output);
            tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);

            pane.add(tabbedPane, c);

        } else {
            output.setPreferredSize(new Dimension(376, 160));
            output.setBorder(BorderFactory.createTitledBorder(" Output Log "));
            pane.add(output, c);
        }
        return pane;
    }

    /**
     * To get the progress bar.
     * 
     * @param sendCount JProgressBar
     * @return JProgressBar
     */
    private JProgressBar getProgressBar(String sendCount) {
        progressBar = new JProgressBar(0, 500);

        progressBar.setPreferredSize(new Dimension(100, 22));
        progressBar.setValue(0);
        progressBar.setStringPainted(true);

        if (sendCount != null && !sendCount.equals("null")) {
            lengthOfTask = Integer.parseInt(sendCount);
            progressBar.setMaximum(lengthOfTask);
        }
        return progressBar;
    }

    /**
     * To get the timer for the progress bar.
     * 
     * @param subType Timer
     * @return Timer
     */
    private Timer getTimer(final String subType) {
        timer = new Timer(200, new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                String label = "";
                if (subType.equals(MainPanel.PRODUCER) || subType.equals(MainPanel.PUBLISHER)) {
                    label = "Sent:";
                } else {
                    label = "Read:";
                }

                if (modulusCounter > progressBar.getMaximum()) {
                    modulusCounter = 0;
                    progressBar.setValue(progressBar.getMinimum());
                }
                progressBar.setValue(modulusCounter);
                progressBar.setString(label + current);
                if (statMessage != null) {
                    if (progressBar.isIndeterminate()) {
                        progressBar.setMaximum(lengthOfTask);
                        progressBar.setIndeterminate(false);
                        progressBar.setString(null); // display % string
                    }
                }
                if (isDone()) {
                    Toolkit.getDefaultToolkit().beep();
                    timer.stop();
                }
            }
        });

        return timer;
    }

    /**
     * Called from ProgressBarDemo to find out if the task has completed.
     * 
     * @return boolean
     */
    private boolean isDone() {
        return done;
    }

    /**
     * To reset the progress bar.
     */
    private void resetProgressBar() {
        current = 0;
        modulusCounter = 0;
        progressBar.setValue(progressBar.getMinimum());
    }

    /**
     * Get input area panel.
     * 
     * @param inputFile JPanel
     * @return JPanel
     */
    private JPanel getInputAreaPanel(String inputFile) {
        taInput = new JTextArea(6, 200);

        if (inputFile != null) {
            taInput.setText("");
            File input = new File(inputFile);
            if (input != null) {
                BufferedReader bufferedreader;
                try {
                    bufferedreader = new BufferedReader(new InputStreamReader(new FileInputStream(input)));
                    String line = bufferedreader.readLine();
                    for (int k = 0; line != null; k++) {
                        taInput.append(line);
                        line = bufferedreader.readLine();
                    }
                } catch (Exception e) {
                    // mainPanel.messageBox(mainPanel.frame, e.getMessage());
                }
            }
        }

        taInput.setFont(new Font("Serif", Font.TRUETYPE_FONT, 12));
        taInput.setLineWrap(true);
        taInput.setWrapStyleWord(true);

        JScrollPane areaScrollPane = new JScrollPane(taInput);
        areaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        JPanel pane = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER; // end row
        c.weightx = 1;
        c.weighty = 0;

        pane.add(getInputContextToolBarPanel(inputFile), c);
        c.weighty = 1;
        pane.add(areaScrollPane, c);

        return pane;
    }

    
    /**
     * Get input area panel.
     * 
     * @param inputFile JPanel
     * @return JPanel
     */
    private JPanel getMessagePropertiesPanel() {
        JPanel cPane = new JPanel(new GridBagLayout());
        List messagePropertiesList = client.getMessagePropertyList();
        
        if (messagePropertiesList != null && messagePropertiesList.size() > 0) {
            JComboBox cbPropertyType = new JComboBox(MessageProperty.PROPERTY_TYPES);
            cbPropertyType.setEnabled(false);
            
            JTextField tfPropertyName = new JTextField("", 8);
            tfPropertyName.setEditable(false);
            
            JTextField tfValue = new JTextField("", 15);
            tfValue.setEditable(false);
            
            JLabel lId = new JLabel(MessageProperty.LABEL_NAME);
            JLabel lType = new JLabel(MessageProperty.LABEL_TYPE);
            JLabel lValue = new JLabel(MessageProperty.LABEL_VALUE);

            MessageProperty property = (MessageProperty)client.getMessagePropertyList().get(0);
            tfPropertyName.setText(property.getName());
            cbPropertyType.setSelectedItem(property.getType());
            tfValue.setText(property.getValue());
            
            lId.setLabelFor(tfPropertyName);
            lValue.setLabelFor(tfValue);
            
            GridBagConstraints c = new GridBagConstraints();
            
            c.anchor = GridBagConstraints.NORTH;
            //c.gridwidth = GridBagConstraints.RELATIVE; 
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = .5;
            c.weighty = 0;
            c.gridx = 0;
            c.gridy = 0;
            cPane.add(lId, c);
            
            c.gridx = 1;
            c.gridy = 0;
            cPane.add(lType, c);
            
            c.gridx = 2;
            c.gridy = 0;
            cPane.add(lValue, c);
            
            c.gridx = 0;
            c.gridy = 1;
            cPane.add(tfPropertyName, c);
            
            c.gridx = 1;
            c.gridy = 1;
            cPane.add(cbPropertyType, c);
            
            c.gridx = 2;
            c.gridy = 1;
            cPane.add(tfValue, c);
        } else {
            JLabel lNoPropertyConfigured = new JLabel("<html>Message Properties not configured,<br>To configure go to configuration section</html>");
            cPane.add(lNoPropertyConfigured);
        }
        return cPane;
    }

    
    /**
     * Get the input context tool bar panel.
     * 
     * @param inputFile JPanel
     * @return JPanel
     */
    private JPanel getInputContextToolBarPanel(String inputFile) {

        JPanel pane = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        JLabel label = new JLabel("   Input File: " + inputFile);
        File f = new File(inputFile);
        if (!f.exists()) {
            label.setForeground(Color.RED);
        }
        label.setPreferredSize(new Dimension(280, 10));
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        pane.add(label, c);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        pane.add(new JLabel(""), c);
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        pane.add(getSeperator(), c);
        c.gridwidth = GridBagConstraints.REMAINDER; // end row
        pane.add(getClearConsoleButton("input"), c);
        return pane;
    }

    /**
     * To get the output area panel.
     * 
     * @return JPanel
     */
    private JPanel getOutputAreaPanel() {
        taOutput = new JTextArea(6, 230);

        taOutput.setFont(new Font("Serif", Font.TRUETYPE_FONT, 12));
        taOutput.setLineWrap(true);
        taOutput.setEditable(false);
        taOutput.setWrapStyleWord(true);

        JScrollPane areaScrollPane = new JScrollPane(taOutput);
        areaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        JPanel pane = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER; // end row
        c.weightx = 1;
        c.weighty = 0;
        pane.add(getOutputContextToolBarPanel(), c);

        c.weighty = 1;
        c.gridheight = GridBagConstraints.RELATIVE; // next-to-last
        pane.add(areaScrollPane, c);

        return pane;
    }

    /**
     * Get the output panel.
     * 
     * @return JPanel
     */
    private JPanel getOutputContextToolBarPanel() {

        JLabel lLogging = new JLabel("Log:");
        final JPanel refreshPanel = getRefreshPanel();
        refreshPanel.setVisible(false);

        String[] loggingOptions = MainPanel.loggingOptions;
        final JComboBox cbLogging = new JComboBox(loggingOptions);

        String logging = client.getLogging();
        cbLogging.setSelectedItem(logging);

        if (MainPanel.MAX.equals(logging)) {
            clientLoggingLevel = MAXIMUM;
        } else if (MainPanel.MAX.equals(logging)) {
            clientLoggingLevel = MINIMUM;
        } else {
            clientLoggingLevel = BENCHMARKING;
        }

        if (MainPanel.BENCHMARKING.equals(logging)) {
            refreshPanel.setVisible(true);
        }

        lLogging.setLabelFor(cbLogging);
        cbLogging.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                if (cbLogging.getSelectedItem().equals(MainPanel.MAX)) {
                    refreshPanel.setVisible(false);
                    clientLoggingLevel = MAXIMUM;
                    client.setLogging(MainPanel.MAX);
                } else if (cbLogging.getSelectedItem().equals(MainPanel.MIN)) {
                    refreshPanel.setVisible(false);
                    clientLoggingLevel = MINIMUM;
                    client.setLogging(MainPanel.MIN);
                } else {
                    clientLoggingLevel = BENCHMARKING;
                    refreshPanel.setVisible(true);
                    client.setLogging(MainPanel.BENCHMARKING);
                }

                if (worker != null) {
                    worker.updateLogging();
                }
            }
        });

        JPanel pane = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        pane.add(lLogging, c);
        pane.add(cbLogging, c);
        c.fill = GridBagConstraints.NONE;

        c.fill = GridBagConstraints.HORIZONTAL;
        pane.add(refreshPanel, c);
        c.weightx = 1;
        pane.add(new JLabel(""), c);
        c.weightx = 0;
        pane.add(getSeperator(), c);

        c.gridwidth = GridBagConstraints.REMAINDER; // end row
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        pane.add(getClearConsoleButton("output"), c);
        return pane;
    }

    /**
     * Get the refresh panel.
     * 
     * @return JPanel
     */
    private JPanel getRefreshPanel() {

        final String every = " Every:";
        final String refresh = " Refresh:";
        
        final JLabel lRefresh = new JLabel(every);
        tfRefresh = new JTextField("100", 5);
        lRefresh.setLabelFor(tfRefresh);

        String[] refreshOptions = { MainPanel.SECONDS, MainPanel.MINUTES, MainPanel.RECEIVE_COUNT };
        cbRefresh = new JComboBox(refreshOptions);

        cbRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                if(cbRefresh.getSelectedItem().equals(MainPanel.SECONDS)) {
                    lRefresh.setText(refresh);
                    tfRefresh.setText("15");
                } else if(cbRefresh.getSelectedItem().equals(MainPanel.MINUTES)) {
                    lRefresh.setText(refresh);
                    tfRefresh.setText("1");
                } else if(cbRefresh.getSelectedItem().equals(MainPanel.RECEIVE_COUNT)) {
                    lRefresh.setText(every);
                    tfRefresh.setText("100");
                }
            }
        });
        cbRefresh.setSelectedItem(MainPanel.RECEIVE_COUNT);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 1;

        panel.add(lRefresh, c);
        panel.add(tfRefresh, c);
        panel.add(cbRefresh, c);
        //c.weightx = 0;
        panel.add(getRefreshButton(), c);

        return panel;
    }

    /**
     * Calculate delay for the timer thread for the benchmark testing.
     * 
     * @param interval String
     * @param timeUnit String
     * @return int
     */
    private int calculateDelay(int interval, String timeUnit) {
        int u = timeUnit == MainPanel.SECONDS ? 1 : 60;
        return 1000 * interval * u;
    }

    /**
     * Get Refresh button.
     * 
     * @return JButton
     */
    private JButton getRefreshButton() {
        JButton bRefresh = new JButton();
        bRefresh.setPreferredSize(new Dimension(24, 20));
        bRefresh.setToolTipText("Refresh");
        bRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                toggleBenchmarkOutputFlag();
            }
        });
        bRefresh.setEnabled(true);
        bRefresh.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/refresh.gif")));
        return bRefresh;
    }

    /**
     * Get clear console button.
     * 
     * @param consoleType String
     * @return JButton
     */
    private JButton getClearConsoleButton(final String consoleType) {
        JButton bClearConsole = new JButton();
        bClearConsole.setPreferredSize(new Dimension(24, 20));
        bClearConsole.setToolTipText("Clear Console");
        bClearConsole.setActionCommand(consoleType);
        bClearConsole.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                if (consoleType.equals("input")) {
                    taInput.setText("");
                } else {
                    taOutput.setText("");
                }
            }
        });
        bClearConsole.setEnabled(true);
        bClearConsole.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/clear_console.png")));
        return bClearConsole;
    }

    /**
     * To create benchmark timer.
     */
    private void createBenchmarkTimer(int delay) {
        timerBenchmarking = new Timer(delay, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if (timerBenchmarking.isRunning()) {
                    toggleBenchmarkOutputFlag();
                }
            }
        });
    }
    
    private void initBenchmarkingTasks() {
        lastElapsedTime = 0;
        receiveCountForBenchmarking = getIntValue(tfRefresh.getText());
        refreshInterval = calculateDelay(getIntValue(tfRefresh.getText()),
                (String) cbRefresh.getSelectedItem());
        createBenchmarkTimer(refreshInterval);
        timerBenchmarking.start();

        flagWriteOutoutForBenchmark = true;
        tfRefresh.setEnabled(false);
        cbRefresh.setEnabled(false);
    }

    private int getIntValue(String str) {
        int number = 1;
        try {
            number = Integer.parseInt(str);
        } catch(NumberFormatException e) {
            mainPanel.messageBox("Exception: " + e.getMessage());
        }
        return number;
    }
    
    /**
     * To toggle the flag for outputting messages during the benchmark log setting.
     */
    private void toggleBenchmarkOutputFlag() {
        // Following check would not allow the timer thread for the benchmarking to toggle the
        // flag before the first message arrives. This ensures that first message is printed.
        if (current == 0) {
            return;
        }
        
        if (flagWriteOutoutForBenchmark) {
            flagWriteOutoutForBenchmark = false;
        } else {
            flagWriteOutoutForBenchmark = true;
        }
    }
    
    /**
     * @param output String
     * @param logLevel int
     */
    private void appendOutput(String output, float elapsedTime, int logLevel) {
        if ((logLevel == LOGGING_LEVEL_CONNECTION_STATUS) || (logLevel == LOGGING_LEVEL_ERROR)) {
            printOutput(output);
        } else {
            switch (clientLoggingLevel) {
            case 1: /* Benchamarking */
                float throughput = -1;
                if(logLevel != LOGGING_LEVEL_BENCHMARK) {
                    return;
                }
                
                if (cbRefresh.getSelectedItem().equals(MainPanel.RECEIVE_COUNT)) {
                    /*This is explicit refresh call by the user, cannot calculate the throughput for this */
                    if (flagWriteOutoutForBenchmark) {
                        printOutput(output);
                        toggleBenchmarkOutputFlag();
                    } else if (receiveCountForBenchmarking != 0 && (current % receiveCountForBenchmarking) == 0) {
                        throughput = (receiveCountForBenchmarking * 1000) / (elapsedTime - lastElapsedTime);
                        lastElapsedTime = elapsedTime;
                        printOutput(output + " [" + formatter.format(throughput) + "]");
                    }
                } else {
                    /*For the case where the seleted option for refresh is time duration */
                    /*TO DO : If the user presses refresh explcicityly, cannot calculate the throughput for this,
                     * however the following gets called by the timer logic also, hence the throughput value shown for the explicity
                     * call would not be valid */
                    if (flagWriteOutoutForBenchmark) {
                        throughput = ((current - lastCount) * 1000) / refreshInterval;
                        lastCount = current;
                        printOutput(output + " [" + formatter.format(throughput) + "]");
                        toggleBenchmarkOutputFlag();
                    }
                }
                
                break;
            case 2: /* Minimum */
                break;
            case 3: /* Maximum */
                if(logLevel != LOGGING_LEVEL_BENCHMARK) {
                    printOutput(output);
                }
                break;
            }
        }
    }

    /**
     * To stop the running client.
     */
    public final void stopClient() {
        final String type = client.getType();
        final String subType = client.getSubType();

        String logging = client.getLogging();
        if (MainPanel.BENCHMARKING.equals(logging)) {
            if (timerBenchmarking != null) {
                timerBenchmarking.stop();
            }
            tfRefresh.setEnabled(true);
            cbRefresh.setEnabled(true);
        }

        try {
            if (type.equals(MainPanel.QUEUE)) {
                if (subType.equals(MainPanel.PRODUCER)) {
                    if (null != qProdr) {
                        qProdr.stop();
                    }
                } else {
                    if (null != qConsr) {
                        qConsr.stop();
                    }
                }
            } else {
                if (subType.equals(MainPanel.PUBLISHER)) {
                    if (null != topicPub) {
                        topicPub.stop();
                    }
                } else {
                    if (null != topicsub) {
                        topicsub.stop();
                    }
                }
            }
            if (worker != null) {
                worker.stop();
                appendOutput("Stopped ...", -1, LOGGING_LEVEL_CONNECTION_STATUS);
                toggleState();
            }
        } catch (Exception e) {
            canceled = true;
            mainPanel.messageBox("Exception: " + e.getMessage());
            toggleState();
        }
    }

    /**
     * Toggle the start and stop button enabled state.
     */
    private synchronized void toggleState() {
        if (bStart.isEnabled()) {
            bStart.setEnabled(false);
        } else {
            bStart.setEnabled(true);
        }

        if (bStop.isEnabled()) {
            bStop.setEnabled(false);
        } else {
            bStop.setEnabled(true);
        }
    }

    /**
     * @param output String
     */
    private void printOutput(String output) {
        taOutput.append(output + "\n");
        taOutput.setCaretPosition(taOutput.getDocument().getLength());
    }

    /**
     * @param message String
     */
    private void handleException(String message) {
        canceled = true;
        appendOutput("Exception: " + message, -1,  2);
        mainPanel.messageBox("Exception: " + message);
        toggleState();
    }

    /**
     * @author mbhasin
     *  
     * The class that actually performs the task of sending or receving messages. It extends Swingworker
     * class, The prime reason for using swingworker is to have the abitily to interrupt the running task which
     * can happen for one of the two following situations 1. The user loads the property sheet again. In this
     * case all the running tasks will be interrupted 2. The user clicks the stop button explicity
     */
    public class JMSTask extends SwingWorker {

        private Properties prop = null;
        private boolean interrupted = false;
        final String type = client.getType();
        final String subType = client.getSubType();
        final String sendCount = client.getSendCount();
        // TODO the user can change the properties, read from the mes property tab sheet values
        final List messagePropertiesList = client.getMessagePropertyList();


        /**
         * @param prop Properties
         */
        public JMSTask(final Properties properties) {
            this.prop = properties;
        }

        /*
         * (non-Javadoc)
         * 
         * @see jmstest.SwingWorker#construct()
         */
        public Object construct() {

            prop.setProperty(MainPanel.JMS_CLIENT_NAME, client.getName());

            progressBar.setString("");
            done = false;
            statMessage = null;
            timer.start();
            Object obj = null;

            if (MainPanel.BENCHMARKING.equals(client.getLogging())) {
                initBenchmarkingTasks();
            }
            
            try {
                toggleState();
                resetProgressBar();
                canceled = false;
                if (type.equals(MainPanel.QUEUE)) {
                    if (subType.equals(MainPanel.PRODUCER)) {
                        tabbedPane.setSelectedIndex(1);
                        prop.setProperty(MainPanel.MESSAGE, taInput.getText());
                        qProdr = new QSender(this, prop, sendCount, messagePropertiesList);
                        qProdr.startQueueSender(client.getLogging());
                        obj = qProdr;
                    } else {
                        qConsr = new QReceiver(this, prop);
                        qConsr.startQueueReceiver(client.getLogging());
                        obj = qConsr;
                    }
                } else {
                    if (subType.equals(MainPanel.PUBLISHER)) {
                        tabbedPane.setSelectedIndex(1);
                        prop.setProperty(MainPanel.MESSAGE, taInput.getText());
                        topicPub = new PublishTopic(this, prop, sendCount);
                        topicPub.start(client.getLogging());
                        obj = topicPub;
                    } else {
                        topicsub = new SubscribeTopic(this, prop);
                        topicsub.start(client.getLogging());
                        obj = topicsub;
                    }
                }
                if (!canceled) {
                    toggleState();
                }
            } catch (Exception e) {
                if (!interrupted) {
                    handleException(e.getMessage());
                }
            }
            return obj;
        }

 
        /**
         * @param output
         * @param elapsedTime
         * @param logLevel
         */
        public final void writeOutput(String output,  long elapsedTime, int logLevel) {
            if (!interrupted) {
                appendOutput(output, elapsedTime, logLevel);
            }
        }

        
        /**
         * Increment Count.
         */
        public final void incrementCurrent() {
            ++current;
            ++modulusCounter;
        }

        /**
         * Task is done.
         */
        public final void isDone() {
            done = true;
        }

        /**
         * Task is stopped.
         */
        public final void isStopped() {
            canceled = true;
        }

        public void updateLogging() {
            if (type.equals(MainPanel.QUEUE)) {
                if (subType.equals(MainPanel.PRODUCER)) {
                    qProdr.setLogging(client.getLogging());
                } else {
                    qConsr.setLogging(client.getLogging());
                }
            } else {
                if (subType.equals(MainPanel.PUBLISHER)) {
                    topicPub.setLogging(client.getLogging());
                } else {
                    topicsub.setLogging(client.getLogging());
                }
            }
        }

        /**
         * Stop Task.
         */
        private void stop() {
            interrupt();
            interrupted = true;
        }
    }
}
