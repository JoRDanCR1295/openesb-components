package com.malkit.jmstest.testclient;

import java.util.Properties;

import com.malkit.jmstest.MainPanel;

/**
 * @author malkit
 */
public class TestClient {
    
    protected String host;
    protected String port;
    protected String login;
    protected String password;
    
    public TestClient(Properties prop) {
        this.host = new String(prop.getProperty(MainPanel.HOST));
        this.port = new String(prop.getProperty(MainPanel.PORT));
        this.login = new String(prop.getProperty(MainPanel.LOGIN));
        this.password = new String(prop.getProperty(MainPanel.PASSWORD));
    }
}
