package com.malkit.jmstest.configeditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.SwingUtilities;


import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.malkit.jmstest.JMSClient;
import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.MessageProperty;

public class Parser {
    /**
     * Property File name
     */
    static String propFileName = "JMSTestProp.xml";
    //static String propFileName = "jmstest/configurationEditor/JMSTestProp.xml";

    public static Properties getConnectionProperties() throws Exception {
        Properties connectionProperties = null;

        Document document = DOMUtil.parse(propFileName);
        if (document != null) {
            // DOMUtil.printDOM(document);
            connectionProperties = getConnectionProperties(document);
        } else {
            throw new Exception("Properties File Reading Exception");
        }
        return connectionProperties;
    }

    public static List getJMSClientList() {
        List clientList = null;
        Document document = null;

        document = DOMUtil.parse(propFileName);
        if (document != null) {
            // DOMUtil.printDOM(document);
            clientList = getJMSClientConfig(document);
        }
        return clientList;
    }

    private static Properties getConnectionProperties(Document document) {

        Properties prop = new Properties();
        NodeList groupList = document.getElementsByTagName(MainPanel.CONNECTIONPROPERTIES);

        for (int i = 0; i < groupList.getLength(); i++) {
            Node group = groupList.item(i);

            if ((Node.ELEMENT_NODE == group.getNodeType())) {
                NodeList testunitList = group.getChildNodes();

                for (int j = 0; j < testunitList.getLength(); j++) {
                    Node testunit = testunitList.item(j);

                    if ((Node.ELEMENT_NODE == testunit.getNodeType())) {
                        if (testunit.getNodeName().equals(MainPanel.SERVER)) {
                            prop.put(MainPanel.SERVER, getValue(testunit));
                        } else if (testunit.getNodeName().equals(MainPanel.HOST)) {
                            prop.put(MainPanel.HOST, getValue(testunit));
                        } else if (testunit.getNodeName().equals(MainPanel.PORT)) {
                            prop.put(MainPanel.PORT, getValue(testunit));
                        } else if (testunit.getNodeName().equals(MainPanel.LOGIN)) {
                            prop.put(MainPanel.LOGIN, getValue(testunit));
                        } else if (testunit.getNodeName().equals(MainPanel.PASSWORD)) {
                            prop.put(MainPanel.PASSWORD, getValue(testunit));
                        } 
                    }
                }

            }
        }
        return prop;
    }

    private static List getJMSClientConfig(Document document) {

        String name = "";
        String type = "";
        String subtype = "";
        String count = "";
        String inputfile = "";
        String logging = "";
        String progressbar = "";
        String groupid = "";
        List propertiesList = null;
        
        JMSClient jmsClient = null;
        List list = new ArrayList();

        NodeList groupList = document.getElementsByTagName("group");
        for (int i = 0; i < groupList.getLength(); i++) {
            Node group = groupList.item(i);

            if ((Node.ELEMENT_NODE == group.getNodeType())) {

                NamedNodeMap attrs = group.getAttributes();
                for (int ii = 0; ii < attrs.getLength(); ii++) {
                    Node attr = attrs.item(ii);
                    if (attr.getNodeName().trim().equals("id")) {
                        groupid = attr.getNodeValue().trim();
                    }
                }

                NodeList testunitList = group.getChildNodes();

                for (int j = 0; j < testunitList.getLength(); j++) {
                    Node testunit = testunitList.item(j);

                    if ((Node.ELEMENT_NODE == testunit.getNodeType())) {

                        NodeList childrens = testunit.getChildNodes();

                        for (int k = 0; k < childrens.getLength(); k++) {

                            Node childNode = childrens.item(k);

                            if (childNode.getNodeName().equals("name")) {
                                name = getValue(childNode);
                            } else if (childNode.getNodeName().equals("type")) {
                                type = getValue(childNode);
                            } else if (childNode.getNodeName().equals("subtype")) {
                                subtype = getValue(childNode);
                            } else if (childNode.getNodeName().equals("count")) {
                                count = getValue(childNode);
                            } else if (childNode.getNodeName().equals("inputfile")) {
                                inputfile = getValue(childNode);
                            } else if (childNode.getNodeName().equals("logging")) {
                                logging = getValue(childNode);
                            } else if (childNode.getNodeName().equals("progressbar")) {
                                progressbar = getValue(childNode);
                            } else if (childNode.getNodeName().equals(MainPanel.MESSAGE_PROPERTIES)) {
                                NodeList propertiesNodeList = childNode.getChildNodes();
                                propertiesList = new ArrayList();
                                String propName = null;
                                String propType = null;
                                String propValue = null;
                                
                                for (int l = 0; l < propertiesNodeList.getLength(); l++) {
                                    Node propertyNode = propertiesNodeList.item(l);
                                    NamedNodeMap attributesMap = propertyNode.getAttributes();
                                    for (int m = 0; m < attributesMap.getLength(); m++) {
                                        Node attribute = attributesMap.item(m);
                                        if (attribute.getNodeName().trim().equals(MessageProperty.LABEL_NAME)) {
                                            propName = attribute.getNodeValue().trim();
                                        } else if (attribute.getNodeName().trim().equals(MessageProperty.LABEL_TYPE)) {
                                            propType = attribute.getNodeValue().trim();
                                        } else if (attribute.getNodeName().trim().equals(MessageProperty.LABEL_VALUE)) {
                                            propValue = attribute.getNodeValue().trim();
                                        }
                                    }
                                    MessageProperty messageProperty = new MessageProperty(propName, propType, propValue);
                                    propertiesList.add(messageProperty);
                                }
                            }
                        }
                        jmsClient = new JMSClient(name, count, type, subtype, inputfile);
                        jmsClient.setGroupid(groupid);
                        jmsClient.setInputfile(inputfile);
                        jmsClient.setLogging(logging);
                        jmsClient.setMessagePropertyList(propertiesList);
                        list.add(jmsClient);
                    }
                }
            }
        }
        return list;
    }

    public static boolean writeFile(final Properties prop, final List jmsClientList) {
        //if (jmsClientList != null && jmsClientList.size() > 0) {
        if (jmsClientList != null) {

            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    CreateConfigurationDOM configDocument = new CreateConfigurationDOM(prop, jmsClientList);
                    Document document = configDocument.getDocument();
                    DOMUtil.writeXmlToFile(propFileName, document);
                }
            });
        }
        return false;
    }

    private static String getValue(Node element) {
        String value = "";

        if ((Node.ELEMENT_NODE == element.getNodeType())) {
            NodeList child = element.getChildNodes();

            for (int l = 0; l < child.getLength(); l++) {
                Node attr = child.item(l);

                if ((Node.TEXT_NODE == attr.getNodeType()) && (attr.getNodeValue() != null)) {
                    value = attr.getNodeValue().trim();
                }
            }
        }
        return value;
    }

    public static void main(String[] args) {
        List list = Parser.getJMSClientList();
        System.out.print(list.size());
    }

    public static void createPropFile() {
        final Properties generalProp = new Properties();
        generalProp.put(MainPanel.HOST, "");
        generalProp.put(MainPanel.PORT, "18007");
        generalProp.put(MainPanel.LOGIN, "Administrator");
        generalProp.put(MainPanel.PASSWORD, "STC");
        
        writeFile(generalProp, null);
    }
}
