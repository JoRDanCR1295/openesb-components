/**
 * 
 */
package com.malkit.jmstest.configeditor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.malkit.jmstest.JMSClient;
import com.malkit.jmstest.MainPanel;

class Configuration extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTextField tfName = null;

    private JComboBox cbType = null;

    private JComboBox cbSubType = null;

    private JComboBox cbLogging = null;

    private JTextField tfCount = null;

    private JTextField tfInputFile = null;

    private JTextField tfMsgProperties = null;

    private List messagePropertiesList = null;

    JButton bFileChooser = null;

    JButton bMsgProperyDialog = null;

    String[] types = { MainPanel.QUEUE, MainPanel.TOPIC };

    String[] queueTypes = { MainPanel.PRODUCER, MainPanel.CONSUMER };

    JFileChooser fc = null;

    JPanel cPane = null;

    private String groupId = null;

    private JMSClient jmsClient = null;

    public Configuration(JMSClient client, String name) {
        this.jmsClient = client;
        this.tfName = new JTextField(name, 10);
        this.tfCount = new JTextField("1", 10);
        this.tfInputFile = new JTextField("", 8);
        this.tfMsgProperties = new JTextField("<not set>", 5);
        this.tfMsgProperties.setEditable(false);

        this.fc = new JFileChooser();

        JLabel lName = new JLabel("Name :");
        lName.setLabelFor(tfName);

        JLabel lType = new JLabel("Type :");
        final JLabel lSubType = new JLabel("Sub Type :");
        final JLabel lLogging = new JLabel("Logging Level:");
        final JLabel lCount = new JLabel("Send Count :");
        final JLabel lInputFile = new JLabel("Input File :");
        final JLabel lMessageProperties = new JLabel("Msg Properties:");

        lInputFile.setLabelFor(tfInputFile);
        lMessageProperties.setLabelFor(tfMsgProperties);

        cbType = new JComboBox(types);
        lType.setLabelFor(cbType);

        cbType.setSelectedIndex(0);
        cbType.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                cbSubType.removeAllItems();
                if (cbType.getSelectedItem().equals(MainPanel.QUEUE)) {
                    cbSubType.addItem(MainPanel.PRODUCER);
                    cbSubType.addItem(MainPanel.CONSUMER);
                } else {
                    cbSubType.addItem(MainPanel.PUBLISHER);
                    cbSubType.addItem(MainPanel.SUBSCRIBER);
                }
            }
        });

        cbSubType = new JComboBox(queueTypes);
        lSubType.setLabelFor(cbSubType);
        cbSubType.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                if (cbSubType != null && cbSubType.getSelectedItem() != null) {
                    if (cbSubType.getSelectedItem().equals(MainPanel.CONSUMER)
                            || cbSubType.getSelectedItem().equals(MainPanel.SUBSCRIBER)) {
                        tfCount.setEnabled(false);
                        tfInputFile.setEnabled(false);
                        lCount.setEnabled(false);
                        lInputFile.setEnabled(false);
                        lMessageProperties.setEnabled(false);
                        bFileChooser.setEnabled(false);
                        bMsgProperyDialog.setEnabled(false);
                        tfMsgProperties.setText("---");

                    } else {
                        tfCount.setEnabled(true);
                        tfInputFile.setEnabled(true);
                        lCount.setEnabled(true);
                        lInputFile.setEnabled(true);
                        bFileChooser.setEnabled(true);
                    }
                }
            }
        });

        cbLogging = new JComboBox(MainPanel.loggingOptions);
        cbLogging.setSelectedItem(MainPanel.MAX);
        lLogging.setLabelFor(cbLogging);
        cbLogging.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {

            }
        });

        cPane = new JPanel();
        // cPane.setPreferredSize(new Dimension(200, 120));
        cPane.setLayout(new GridBagLayout());
        cPane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Test Client"),
                BorderFactory.createEmptyBorder(1, 1, 1, 1)));

        cPane.setLayout(new GridBagLayout());

        JLabel[] labels = { lName, lType, lSubType, lCount };
        JComponent[] textFields = { tfName, cbType, cbSubType, tfCount };
        addLabelTextRows(labels, textFields, cPane);

        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.gridwidth = GridBagConstraints.RELATIVE;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.weighty = 0;
        cPane.add(lInputFile, c);
        c.gridwidth = GridBagConstraints.REMAINDER;
        cPane.add(getFileChooserButton(tfInputFile), c);

        c.gridwidth = GridBagConstraints.RELATIVE;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;
        c.weighty = 0;

        cPane.add(lMessageProperties, c);
        c.gridwidth = GridBagConstraints.REMAINDER;
        cPane.add(getMsgPropertiesButton(tfMsgProperties), c);

        c.gridwidth = GridBagConstraints.RELATIVE;
        c.weightx = 1.0;
        c.weighty = 0;

        cPane.add(lLogging, c);
        cPane.add(cbLogging, c);
    }

    public void initialize() {
        tfName.setText(jmsClient.getName());
        cbType.setSelectedItem(jmsClient.getType());
        cbSubType.setSelectedItem(jmsClient.getSubType());
        cbLogging.setSelectedItem(jmsClient.getLogging());
        tfCount.setText(jmsClient.getSendCount());
        tfInputFile.setText(jmsClient.getInputfile());
        File f = new File(jmsClient.getInputfile());
        if (!f.exists()) {
            tfInputFile.setForeground(Color.RED);
        } else {
            fc.setCurrentDirectory(f);
            fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        }
        messagePropertiesList = jmsClient.getMessagePropertyList();
        if (messagePropertiesList != null && messagePropertiesList.size() > 0) {
            tfMsgProperties.setText("<set>");
            tfMsgProperties.setForeground(Color.blue);
        } else {
            tfMsgProperties.setText("<not set>");
            tfMsgProperties.setForeground(Color.RED);
        }
        this.groupId = jmsClient.getGroupid();
    }

    public String getSubType() {
        return (String) cbSubType.getSelectedItem();
    }

    public void setSubType(String subType) {
        cbSubType.setSelectedItem(subType);
    }

    public JPanel getPropertyPanel() {
        return cPane;
    }

    public String getName() {
        return tfName.getText();
    }

    public String getCount() {
        return tfCount.getText();
    }

    public String getType() {
        return (String) cbType.getSelectedItem();
    }

    public void setType(String type) {
        cbType.setSelectedItem(type);
    }

    public String getLogging() {
        return (String) cbLogging.getSelectedItem();
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getInputFile() {
        return tfInputFile.getText();
    }

    public List getMessageProperties() {
        return this.messagePropertiesList;
    }

    private void addLabelTextRows(JLabel[] labels, JComponent[] textFields, JPanel panel) {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.WEST;
        int numLabels = labels.length;

        for (int i = 0; i < numLabels; i++) {
            c.gridwidth = GridBagConstraints.RELATIVE;
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 1.0;
            c.weighty = 0;
            panel.add(labels[i], c);

            c.gridwidth = GridBagConstraints.REMAINDER; // end row
            panel.add(textFields[i], c);
        }
    }

    private Component getFileChooserButton(final JTextField tf) {
        JPanel panel = new JPanel(new GridBagLayout());
        bFileChooser = new JButton("..");
        bFileChooser.setPreferredSize(new Dimension(20, 24));
        bFileChooser.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                int returnVal = fc.showOpenDialog(Configuration.this);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fc.getSelectedFile();
                    tfInputFile.setForeground(Color.BLACK);
                    tf.setText(file.getPath());
                }
            }
        });
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.gridwidth = GridBagConstraints.RELATIVE;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        panel.add(tf, c);
        c.weightx = 0;
        panel.add(bFileChooser, c);
        return panel;
    }

    private Component getMsgPropertiesButton(final JTextField tf) {
        JPanel panel = new JPanel(new GridBagLayout());
        bMsgProperyDialog = new JButton("..");
        bMsgProperyDialog.setPreferredSize(new Dimension(20, 24));
        bMsgProperyDialog.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                MsgPropertiesDialog dialog = new MsgPropertiesDialog(cPane, jmsClient);
                messagePropertiesList = dialog.getMessageProperties();
                if (messagePropertiesList != null) {
                    tfMsgProperties.setText("<set>");
                    tfMsgProperties.setForeground(Color.blue);
                } else {
                    tfMsgProperties.setText("<not set>");
                    tfMsgProperties.setForeground(Color.RED);
                }
            }
        });
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.WEST;
        c.gridwidth = GridBagConstraints.RELATIVE;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        panel.add(tf, c);
        c.weightx = 0;
        panel.add(bMsgProperyDialog, c);
        return panel;
    }
}