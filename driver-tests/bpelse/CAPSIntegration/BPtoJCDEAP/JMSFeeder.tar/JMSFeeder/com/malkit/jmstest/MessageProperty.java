package com.malkit.jmstest;

public class MessageProperty {
    
    public static final String LABEL_TYPE = "Type";
    public static final String LABEL_NAME = "Name";
    public static final String LABEL_VALUE = "Value";
    
    public static final String BOOLEAN = "boolean";
    public static final String BYTE = "byte";
    public static final String SHORT = "short";
    public static final String INT = "int";
    public static final String LONG = "long";
    public static final String FLOAT = "float";
    public static final String DOUBLE = "double";
    public static final String STRING = "String";
    public static final String GUID = "Guid";
    public static final String AUTO_INCREMENT = "Auto Increment";

    public static String[] PROPERTY_TYPES = {MessageProperty.STRING, MessageProperty.BOOLEAN, MessageProperty.BYTE,
            MessageProperty.INT, MessageProperty.LONG, MessageProperty.FLOAT, MessageProperty.DOUBLE,
            MessageProperty.GUID, MessageProperty.AUTO_INCREMENT };
    
    private String name;
    private String value;
    private String type;
    private long lValue;

    public MessageProperty(String name, String type, String value) {
        this.name = name;
        this.type = type;
        this.value = value;
        if (type.equals(AUTO_INCREMENT)) {
            lValue = Long.valueOf(value).longValue();
        }
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getValue() {
        return value;
    }
    
    public long getLongValue() {
        return lValue;
    }
    
    public void incrementLongValue() {
        lValue++;
    }
}
