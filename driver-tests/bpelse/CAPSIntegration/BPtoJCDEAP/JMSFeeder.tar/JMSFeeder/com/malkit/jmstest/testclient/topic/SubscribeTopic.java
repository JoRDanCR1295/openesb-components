package com.malkit.jmstest.testclient.topic;

import java.util.Date;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;


import com.malkit.jmstest.JMSClientView;
import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.JMSClientView.JMSTask;
import com.malkit.jmstest.testclient.TestClient;
import com.stc.jms.client.STCTopicConnectionFactory;

/**
 * @author mbhasin
 */
public class SubscribeTopic extends TopicTestClient {

    private String topicName = null;
    private TopicSession sess = null;
    private JMSTask worker = null;
    private boolean runFlag = true;
    private String logging = null;

    /**
     * @param worker JMSTask
     * @param prop Properties
     * @throws Exception
     */
    public SubscribeTopic(JMSTask worker, Properties prop) throws Exception {
        super(prop);
        this.worker = worker;
        this.topicName = new String(prop.getProperty(MainPanel.JMS_CLIENT_NAME));
    }

    /**
     * @param loggingType String
     * @throws Exception
     */
    public void start(String loggingType) throws Exception {

        this.logging = loggingType;

        worker.writeOutput("Connecting ..... Topic [" + topicName + "]", -1, JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
        sess = con.createTopicSession(true, 0);
        Topic topic = sess.createTopic(topicName);
        TopicSubscriber topicsubscriber = sess.createDurableSubscriber(topic, "Publish Test (FGK)");
        con.start();
        int j = 0;
        long t0 = System.currentTimeMillis();
        worker.writeOutput("Connection established ...", -1, JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
        worker.writeOutput("Current System Time : " + new Date(t0), -1,  JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
        worker.writeOutput("[read count][System Time][Elapsed Time(ms)][throughput (tps)]", -1, JMSClientView.LOGGING_LEVEL_BENCHMARK);
        
        long elapsed;
        
        try {
            do {
                javax.jms.Message message = topicsubscriber.receive(1000L);
                if (message == null) {
                    // break;
                }

                if (message instanceof TextMessage) {
                    worker.incrementCurrent();
                    if (logging.equals(MainPanel.BENCHMARKING)) {
                        elapsed = System.currentTimeMillis() - t0;
                        
                        worker.writeOutput(++j + " [" + new Date(System.currentTimeMillis()) + "] [" + elapsed + " ]", elapsed,
                                JMSClientView.LOGGING_LEVEL_BENCHMARK);
                    } else {
                        worker.writeOutput(++j + " : Reading message : " + ((TextMessage) message).getText(), -1,
                                JMSClientView.LOGGING_LEVEL_INFO);
                    }
                }
            } while (runFlag);

            sess.commit();
            worker.isDone();
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (JMSException e) {
                }
            }
        }
    }

    /**
     * @throws JMSException JMSException
     */
    public synchronized void stop() throws JMSException {
        runFlag = false;
        worker.isStopped();
    }

    /**
     * @param loggingType String
     */
    public void setLogging(String loggingType) {
        this.logging = loggingType;

    }
}
