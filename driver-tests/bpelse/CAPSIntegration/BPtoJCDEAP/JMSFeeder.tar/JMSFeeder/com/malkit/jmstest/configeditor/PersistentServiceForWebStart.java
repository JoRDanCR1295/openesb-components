package com.malkit.jmstest.configeditor;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;

/*import javax.jnlp.BasicService;
import javax.jnlp.FileContents;
import javax.jnlp.FileOpenService;
import javax.jnlp.PersistenceService;
import javax.jnlp.ServiceManager;
import javax.jnlp.UnavailableServiceException;*/

/**
 * Not implemented yet. the code commented.
 * @author mbhasin
 *
 */
public class PersistentServiceForWebStart {

    /*static PersistenceService ps;

    static BasicService bs;

    *//**
     * 
     *//*
    public PersistentServiceForWebStart() {
        try {
            ps = (PersistenceService) ServiceManager.lookup("javax.jnlp.PersistenceService");
            bs = (BasicService) ServiceManager.lookup("javax.jnlp.BasicService");
        } catch (UnavailableServiceException e) {
            ps = null;
            bs = null;
        }
    }

    public static FileContents openFileDialog() {
        FileOpenService fos;
        FileContents fc = null;

        try {
            fos = (FileOpenService) ServiceManager.lookup("javax.jnlp.FileOpenService");
        } catch (UnavailableServiceException e) {
            fos = null;
        }

        if (fos != null) {
            try {
                // ask user to select a file through this service
                fc = fos.openFileDialog(null, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return fc;
    }

    public static OutputStream writeFile(int fileLength) {
        FileContents fc = null;
        OutputStream os = null;
        
        if (ps != null && bs != null) {

            try {
                // find all the muffins for our URL
                URL codebase = bs.getCodeBase();

                // create the file and  
                ps.create(codebase, fileLength);

                os = fc.getOutputStream(false);
                //os.write(buf);
                //os.close();
                

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return os;
    }

    public static FileContents readFile() {
        FileContents fc = null;
        if (ps != null && bs != null) {

            try {
                // find all the muffins for our URL
                URL codebase = bs.getCodeBase();
                fc = ps.get(codebase);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return fc;
    }

    void doUpdateServer(URL url) throws MalformedURLException, IOException {
        // update the server's copy of the persistent data
        // represented by the given URL
        // ...
        ps.setTag(url, PersistenceService.CACHED);
    }*/
}
