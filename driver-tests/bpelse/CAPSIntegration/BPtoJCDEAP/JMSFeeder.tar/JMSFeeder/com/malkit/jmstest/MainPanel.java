package com.malkit.jmstest;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;


import com.l2fprod.common.demo.TaskPaneMain;
import com.malkit.jmstest.configeditor.ConfigurationDialog;
import com.malkit.jmstest.configeditor.Parser;

/**
 * @author mbhasin
 */
public class MainPanel extends JPanel {

    private String VERSION = "0.9.5 Beta";
    private static final long serialVersionUID = 1L;

    public static final String JMS_CLIENT_NAME = "jms_client_name";
    public static final String JAVA_MQ_3_7 = "Java System MQ 3.7";
    public static final String STC_JMS_5_1 = "STC JMS (ICAN 5.1)";
    public static final String JMS_PROPFILE = "jms.prop";

    /* General Properties */
    public static final String CONNECTIONPROPERTIES = "Connection";
    public static final String SERVER = "Server";
    public static final String HOST = "Host";
    public static final String PORT = "Port";
    public static final String LOGIN = "Login";
    public static final String PASSWORD = "Password";
    public static final String MESSAGE = "Message";
    public static final String STOP = "Stop";
    public static final String COUNT = "Num Tries";
    public static final String QUEUE = "Queue";
    public static final String TOPIC = "Topic";
    public static final String PRODUCER = "Producer";
    public static final String CONSUMER = "Consumer";
    public static final String PUBLISHER = "Publisher";
    public static final String SUBSCRIBER = "Subscriber";
    public static final String MESSAGE_PROPERTIES = "properties";
    /* logging levels */
    public static String MAX = "Maximum";
    public static String MIN = "Minimum";
    public static String BENCHMARKING = "Benchmark";
    public static String SECONDS = "Secs";
    public static String MINUTES = "Mins";
    public static String RECEIVE_COUNT = "Count";

    public static String[] loggingOptions = { MainPanel.MAX, MainPanel.MIN, MainPanel.BENCHMARKING };
    private String EDIT_CONFIGURATIONS = "Configurations";
    private static final int MAIN_WINDOW_WIDTH = 800;
    private static final int MAIN_WINDOW_HEIGHT = 660;

    
    public JFrame frame = null;
    private JLabel jLabelServer1;
    private JLabel jLabel21;
    private JLabel jLabel31;

    private CollapsibleWorkbenchPane workbenchPanel = null;
    private JPanel mainPanel = null;

    /**
     * @param frame Frame
     */
    public MainPanel(final JFrame frame) {
        this.frame = frame;

        //setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
        setLayout(new GridBagLayout());
        
        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.CENTER;
        c.fill = GridBagConstraints.BOTH;

        c.weightx = 1;
        c.weighty = 0;
        c.insets = new Insets(1, 1, 1, 1);
        add(getTopLabels(), c);

        c.fill = GridBagConstraints.NONE;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weightx = 0;
        add(getEditConfigurationsButton(), c);

        c.weighty = 1;

        mainPanel = getTestWorkbenchPane(this);
        add(mainPanel, c);

        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.EAST;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weighty = 0;
        c.weightx = 1;
        add(getExitButton(), c);
    }

    /**
     * @return JPanel
     */
    private JPanel getTopLabels() {

        final JLabel jLabelServer = new JLabel((SERVER + " : "));
        jLabelServer1 = new JLabel("");

        final JLabel jLabel2 = new JLabel((HOST + ":" + PORT));
        jLabel21 = new JLabel("");
        final JLabel jLabel3 = new JLabel((LOGIN + ":" + PASSWORD));
        jLabel31 = new JLabel("");

        JPanel panel = new JPanel(new FlowLayout());
        panel.add(jLabelServer);
        panel.add(jLabelServer1);
        panel.add(jLabel2);
        panel.add(jLabel21);
        panel.add(jLabel3);
        panel.add(jLabel31);
        return panel;
    }

    /**
     * @param mainPanel JPanel
     * @return
     */
    private JPanel getTestWorkbenchPane(MainPanel mainPanel) {
        workbenchPanel = new CollapsibleWorkbenchPane(mainPanel);

        Properties prop = null;
        try {
            prop = Parser.getConnectionProperties();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
        if(prop == null) {
            Parser.createPropFile();
            launchConfigurationDialog();
        } else {
            
            List list = Parser.getJMSClientList();
            if (list != null && list.size() == 0) {
                launchConfigurationDialog();
            } else {
                initWorkBench(prop, list);
            }
        }
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setPreferredSize(new Dimension(840, 554));

        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.EAST;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weighty = 1;
        c.weightx = 1;
        panel.add(workbenchPanel, c);
        
        return panel;
    }

    private JButton getEditConfigurationsButton() {
        JButton bAddNewGroup = new JButton(EDIT_CONFIGURATIONS);

        bAddNewGroup.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                launchConfigurationDialog();
            }
        });
        return bAddNewGroup;
    }

    private void launchConfigurationDialog() {
        List list = Parser.getJMSClientList();
        Properties prop = null;
        try {
            prop = Parser.getConnectionProperties();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        ConfigurationDialog configDialog = null;
        try {
            configDialog = new ConfigurationDialog(frame, prop, list);
        } catch (Exception e) {
        }

        final Properties generalProperties = configDialog.getConnectionProperties();
        final List returnedList = configDialog.getTestClientConfigurations();

        if (returnedList != null && returnedList.size() > 0) {
            int n = JOptionPane.showConfirmDialog(frame, "Applying new Configurations would reset all the current JMS Connections\nClick yes to confirm or no to cancel",
                    "Apply New Properties Confirmation", JOptionPane.YES_NO_OPTION);
            if (n == JOptionPane.YES_OPTION) {

                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        workbenchPanel.reset();
                        initWorkBench(generalProperties, returnedList);
                        revalidate();
                        repaint();
                    }
                });
            } else if (n == JOptionPane.NO_OPTION) {
                return;
            }
        }
    }

    private void initWorkBench(Properties prop, List list) {
        jLabelServer1.setText("<html><B>" + prop.getProperty(MainPanel.SERVER) + "</B></html>");
        jLabel21.setText("<html><B>" + prop.getProperty(MainPanel.HOST) + " : " + prop.getProperty(MainPanel.PORT) + "</B></html>");
        jLabel31.setText("<html><B>" + prop.getProperty(MainPanel.LOGIN) + " : " + prop.getProperty(MainPanel.PASSWORD) + "</B></html>");

        for (int i = 0; i < list.size(); i++) {
            workbenchPanel.addGroupPanel((JMSClient) list.get(i), (JMSClient) list.get(++i), prop);
        }
    }

    private JButton getExitButton() {
        final JButton bExit = new JButton("       Exit      ");
        bExit.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                System.exit(0);
            }
        });
        return bExit;
    }

    /**
     * @param frame JFrame
     * @param msg Message
     */
    public final void messageBox(final String msg) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JOptionPane.showMessageDialog(frame, msg);
            }
        });
    }

    /**
     * @param frame JFrame
     * @return JMenuBar
     */
    public JMenuBar createMenuBar(final JFrame frame) {
        JMenuBar menuBar = new JMenuBar();
        JMenu projectMenu = new JMenu("Menu Options");
        menuBar.add(projectMenu);

        JMenuItem loadProject = new JMenuItem("Load Property Editor");
        // projectMenu.add(loadProject);

        loadProject.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // loadProperties(new File(JMS_PROPFILE), frame, false);
            }
        });

        // add menu item
        JMenuItem exit = new JMenuItem("Exit");
        projectMenu.add(exit);
        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // System.exit(0);
                frame.dispose();
            }
        });

        JMenu helpMenu = new JMenu("Help");
        menuBar.add(helpMenu);

        JMenuItem about = new JMenuItem("About");
        about.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                getAboutDialog(frame);
            }
        });
        helpMenu.add(about);

        return menuBar;
    }

    /**
     * @param frame JFrame
     * @return JDialog
     */
    private JDialog getAboutDialog(JFrame frame) {
        final JDialog aboutDialog = new JDialog(frame, "About JMS Test Client");
        aboutDialog.setSize(300, 160);
        aboutDialog.setLocationRelativeTo(frame);
        aboutDialog.setResizable(false);
        aboutDialog.setModal(true);

        JLabel labelIcon = new JLabel("", new ImageIcon(TaskPaneMain.class.getResource("icons/sbyn_logo_about.gif")),
                JLabel.CENTER);

        JPanel cPane = (JPanel) aboutDialog.getContentPane();
        cPane.setLayout(new GridBagLayout());

        JButton jbOk = new JButton("  Ok  ");
        jbOk.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e) {
                aboutDialog.dispose();
            }
        });

        GridBagConstraints c = new GridBagConstraints();

        c.anchor = GridBagConstraints.CENTER;
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER;

        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0, 0, 5, 0);
        cPane.add(getAboutLabel(), c);

        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.WEST;
        c.gridwidth = 1;
        c.weighty = 0;
        c.weightx = 1;
        c.insets = new Insets(0, 0, 5, 5);
        cPane.add(new JPanel(), c);
        // cPane.add(labelIcon, c);

        c.weightx = 0;
        cPane.add(jbOk, c);

        aboutDialog.setVisible(true);
        return aboutDialog;
    }

    /**
     * @return JPanel
     */
    private JPanel getAboutLabel() {
        JPanel pane = new JPanel();
        pane.setLayout(new GridLayout(6, 1));
        pane.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
        pane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel label = new JLabel("<html><b>JMS Test Client</html></b>");
        JLabel label2 = new JLabel("Version: " + VERSION);
        JLabel label21 = new JLabel();
        JLabel label3 = new JLabel("Contributed By: Malkit Singh Bhasin");
        JLabel label4 = new JLabel("Email Questions/Comments or Report Bug at");
        JLabel label5 = new JLabel("malkit.bhasin@sun.com");
        pane.setBackground(new Color(255, 255, 255));

        pane.add(label);
        pane.add(label2);
        pane.add(label21);
        pane.add(label3);
        pane.add(label4);
        pane.add(label5);

        return pane;
    }

    /**
     * @throws Exception exception
     */
    public static void createAndShowGUI() throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        JFrame frame = new JFrame("JMS Test Client");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(MAIN_WINDOW_WIDTH, MAIN_WINDOW_HEIGHT);

        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - frame.getWidth()) / 2, (d.height - frame.getHeight()) / 2);

        MainPanel newContentPane = new MainPanel(frame);

        frame.setJMenuBar(newContentPane.createMenuBar(frame));
        newContentPane.setOpaque(true);
        frame.setContentPane(newContentPane);
        frame.setResizable(true);
        frame.pack();

        frame.setVisible(true);
    }

    /**
     * @param args String[]
     * @throws Exception exception
     */
    public static void main(String[] args) throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    createAndShowGUI();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}