package com.malkit.jmstest.testclient.topic;

import java.util.Date;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;


import com.malkit.jmstest.JMSClientView;
import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.JMSClientView.JMSTask;
import com.malkit.jmstest.testclient.TestClient;
import com.stc.jms.client.STCTopicConnectionFactory;

public class PublishTopic extends TopicTestClient {

    private int message_Count = -1;
    private String inputMessage;
    private String topicName = null;
    private int NUM_MSGS = 1;
    private TopicSession sess = null;
    private JMSTask worker = null;
    private boolean runFlag = true;
    private String logging = null;
    
    /**
     * @param worker
     * @param prop
     * @param count
     * @throws Exception
     */
    public PublishTopic(JMSTask worker, Properties prop, String count) throws Exception {
        super(prop);
        this.worker = worker;
        message_Count = Integer.parseInt(count);
        inputMessage = new String(prop.getProperty(MainPanel.MESSAGE)).trim();
        topicName = new String(prop.getProperty(MainPanel.JMS_CLIENT_NAME));
    }

    /**
     * @throws Exception
     */
    public void start(String loggingType) throws Exception {
        
        this.logging = loggingType;
        
        if (message_Count != -1) {
            NUM_MSGS = message_Count;
        } else {
            NUM_MSGS = 1;
        }

        worker.writeOutput("Connecting ..... ", -1, JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
        sess = con.createTopicSession(true, 0);
        Topic dest1 = sess.createTopic(topicName);
        TopicPublisher prod = sess.createPublisher(dest1);

        worker.writeOutput("Connection established ... for topic [" + topicName + "]", -1,
                JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);

        con.start();

        long t0 = System.currentTimeMillis();
        worker.writeOutput("Current System Time : " + new Date(t0), -1, JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
        worker.writeOutput("[send count][System Time][Elapsed Time(ms)][throughput(tps)]", -1, JMSClientView.LOGGING_LEVEL_BENCHMARK);
        
        TextMessage msg = sess.createTextMessage(inputMessage);
        msg.setLongProperty("T", t0);

        int j = 0;
        long elapsed;
        try {
            for (int i = 0; i < NUM_MSGS && runFlag; i++) {
                prod.publish(msg);
                worker.incrementCurrent();

                if (logging.equals(MainPanel.BENCHMARKING)) {
                    elapsed = System.currentTimeMillis() - t0;
                    
                    worker.writeOutput(++j + " [" + new Date(System.currentTimeMillis()) + "] [" + elapsed + " ]", elapsed, 
                            JMSClientView.LOGGING_LEVEL_BENCHMARK);
                } else {
                    worker.writeOutput(++j + " : Message Sent : " + inputMessage, -1, JMSClientView.LOGGING_LEVEL_INFO);
                }

            }
            sess.commit();
            worker.isDone();

        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (JMSException e) {
                }
            }
        }
    }
    
    /**
     * @param loggingType String
     */
    public void setLogging(String loggingType) {
        this.logging = loggingType;
    }
    

    /**
     * @throws JMSException
     */
    public synchronized void stop() throws JMSException {
        runFlag = false;
        worker.isStopped();
    }

}
