package com.malkit.jmstest.testclient.queue;

import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;

import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.testclient.TestClient;
import com.stc.jms.client.STCQueueConnectionFactory;

public class QTestClient extends TestClient {

    String server = null;
    QueueConnectionFactory queueConnectionFactory = null;
    QueueConnection queueConnection = null;    
    
    public QTestClient(Properties prop) throws JMSException {
        super(prop);
            
        this.server = new String(prop.getProperty(MainPanel.SERVER));
        if (server.equalsIgnoreCase(MainPanel.STC_JMS_5_1)) {
            queueConnectionFactory = new STCQueueConnectionFactory(host, new Integer(port).intValue());
            queueConnection = queueConnectionFactory.createQueueConnection(login, password);
        } else if (server.equalsIgnoreCase(MainPanel.JAVA_MQ_3_7)) {
            queueConnectionFactory = new com.sun.messaging.QueueConnectionFactory();
            ((com.sun.messaging.QueueConnectionFactory)queueConnectionFactory).setProperty("imqBrokerHostName", host);
            ((com.sun.messaging.QueueConnectionFactory)queueConnectionFactory).setProperty("imqBrokerHostPort", port);

            queueConnection = queueConnectionFactory.createQueueConnection();
        }
    }
}
