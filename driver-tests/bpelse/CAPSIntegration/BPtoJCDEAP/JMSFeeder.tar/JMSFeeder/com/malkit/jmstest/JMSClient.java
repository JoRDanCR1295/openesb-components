/**
 * 
 */
package com.malkit.jmstest;

import java.util.List;

public class JMSClient {
    String name;
    String sendCount = "1";
    String type;
    String subType;
	String inputfile;
	String logging = "";
    String groupid;
    List messagePropertyList;
    
	public JMSClient(String jmsClientName, String sendCount, String jmsClientType,
			String jmsClientSubType, String inputFile) {
		this.name = jmsClientName;
		this.sendCount = sendCount;
		this.type = jmsClientType;
		this.subType = jmsClientSubType;
		this.inputfile = inputFile;
	}

	public String getName() {
		return name;
	}

	public String getSubType() {
		return subType;
	}

	public String getType() {
		return type;
	}

	public String getSendCount() {
		return sendCount;
	}

	public String getGroupid() {
		return groupid;
	}

	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}

	public String getInputfile() {
		return inputfile;
	}

	public void setInputfile(String inputfile) {
		this.inputfile = inputfile;
	}

	public String getLogging() {
		return logging;
	}

	public void setLogging(String logging) {
		this.logging = logging;
	}

    public List getMessagePropertyList() {
        return messagePropertyList;
    }

    public void setMessagePropertyList(List messagePropertyList) {
        this.messagePropertyList = messagePropertyList;
    }
}