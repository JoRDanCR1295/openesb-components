/*
 * Copyright 2002 Sun Microsystems, Inc. All Rights Reserved. Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following conditions are met: - Redistributions of source code
 * must retain the above copyright notice, this list of conditions and the following disclaimer. - Redistribution in
 * binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution. Neither the name of Sun Microsystems, Inc. or
 * the names of contributors may be used to endorse or promote products derived from this software without specific
 * prior written permission. This software is provided "AS IS," without a warranty of any kind. ALL EXPRESS OR IMPLIED
 * CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS
 * SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR
 * FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE
 * THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF SUN HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES. You acknowledge that this software is not designed, licensed or intended for use in the
 * design, construction, operation or maintenance of any nuclear facility.
 */
/**
 * The QSender class consists only of a main method, which sends several messages to a queue. Run this program
 * in conjunction with QReceiver. Specify a queue name on the command line when you run the program. By
 * default, the program sends one message. Specify a number after the queue name to send that number of messages.
 */
package com.malkit.jmstest.testclient.queue;

import java.rmi.server.UID;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.malkit.jmstest.JMSClientView;
import com.malkit.jmstest.MainPanel;
import com.malkit.jmstest.MessageProperty;
import com.malkit.jmstest.JMSClientView.JMSTask;

public class QSender extends QTestClient {

    int message_Count = -1;
    String inputMessage;
    String queueName = null;
    QueueSession queueSession = null;
    JMSTask worker = null;
    Queue queue = null;
    QueueSender queueSender = null;
    TextMessage message = null;
    boolean runFlag = false;
    boolean pauseFlag = false;
    private String logging = null;
    List messagePropertiesList = null;
    
    int batchSize = 500;

    public QSender(JMSTask worker, Properties prop, String count, List messagePropertiesList) throws Exception {
        super(prop);
        this.worker = worker;
        this.message_Count = Integer.parseInt(count);
        this.inputMessage = new String(prop.getProperty(MainPanel.MESSAGE));
        this.queueName = new String(prop.getProperty(MainPanel.JMS_CLIENT_NAME));
        this.messagePropertiesList = messagePropertiesList;
    }

    /**
     * @throws Exception
     */
    public void startQueueSender(String loggingType) throws Exception {

        this.logging = loggingType;
        
        final int NUM_MSGS;

        if (message_Count != -1) {
            NUM_MSGS = message_Count;
        } else {
            NUM_MSGS = 1;
        }

        /*
         * Create connection. Create session from connection; false means session is not transacted. Create sender and
         * text message. Send messages, varying text slightly. Send end-of-messages message. Finally, close connection.
         */
        try {
            worker.writeOutput("Connecting ..... queue [" + queueName + "]", -1, 
                    JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
            queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            queue = queueSession.createQueue(queueName);

            worker.writeOutput("Connection established ... ", -1, JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);

            queueSender = queueSession.createSender(queue);
            message = queueSession.createTextMessage();

            long t0 = System.currentTimeMillis();
            
            worker.writeOutput("Current System Time : " + new Date(System.currentTimeMillis()), -1, JMSClientView.LOGGING_LEVEL_CONNECTION_STATUS);
            worker.writeOutput("[send count][System Time][Elapsed Time (ms)][throughput (tps)]", -1, 
                    JMSClientView.LOGGING_LEVEL_BENCHMARK);

            int j = 0;
            long elapsed;
            
            runFlag = true;
            for (int i = 0; i < NUM_MSGS & runFlag; i++) {
                if (pauseFlag) {
                    wait();
                }
                if (i > 0 && (i % batchSize) == 0) {
                    Thread.sleep(60000);
                }
                message.setText(inputMessage);
                
                if (messagePropertiesList != null) {
                    for (int k = 0; k < messagePropertiesList.size(); k++) {
                        MessageProperty property = (MessageProperty) messagePropertiesList.get(k);
                        if (property.getName() != null && !property.getName().equals("")) {
                            if (property.getType().equals(MessageProperty.AUTO_INCREMENT)) {
                                message.setLongProperty(property.getName(), property.getLongValue());
                                property.incrementLongValue();
                            } else if (property.getType().equals(MessageProperty.GUID)) {
                                message.setStringProperty(property.getName(), new UID().toString());
                            } else if (property.getType().equals(MessageProperty.STRING)) {
                                message.setStringProperty(property.getName(), property.getValue());
                            } else if (property.getType().equals(MessageProperty.BOOLEAN)) {
                                message.setBooleanProperty(property.getName(), Boolean.valueOf(property.getValue()).booleanValue());
                            } else if (property.getType().equals(MessageProperty.BYTE)) {
                                message.setByteProperty(property.getName(), Byte.valueOf(property.getValue()).byteValue());
                            } else if (property.getType().equals(MessageProperty.INT)) {
                                message.setIntProperty(property.getName(), Integer.valueOf(property.getValue()).intValue());
                            } else if (property.getType().equals(MessageProperty.LONG)) {
                                message.setLongProperty(property.getName(), Long.valueOf(property.getValue()).longValue());
                            } else if (property.getType().equals(MessageProperty.FLOAT)) {
                                message.setFloatProperty(property.getName(), Float.valueOf(property.getValue()).floatValue());
                            } else if (property.getType().equals(MessageProperty.DOUBLE)) {
                                message.setDoubleProperty(property.getName(), Double.valueOf(property.getValue()).doubleValue());
                            }
                        }
                    }
                }
                queueSender.send(message);
                worker.incrementCurrent();
                
                if (logging.equals(MainPanel.BENCHMARKING)) {
                    elapsed = System.currentTimeMillis() - t0;
                    
                    worker.writeOutput(++j + " [" + new Date(System.currentTimeMillis()) + "] [" + elapsed + " ]", elapsed,
                            JMSClientView.LOGGING_LEVEL_BENCHMARK);
                } else {
                    worker.writeOutput(++j + " : Message Sent : " + inputMessage, -1, JMSClientView.LOGGING_LEVEL_INFO);
                }
            }
            worker.isDone();
        } finally {
            if (queueConnection != null) {
                try {
                    queueConnection.close();
                } catch (JMSException e) {
                }
            }
        }
    }

    /**
     * @param loggingType String
     */
    public void setLogging(String loggingType) {
        this.logging = loggingType;
    }
    
    
    /**
     * @throws JMSException
     */
    public synchronized void stop() throws JMSException {
        runFlag = false;
        worker.isStopped();
    }
}
