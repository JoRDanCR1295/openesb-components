package com.malkit.jmstest.configeditor;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;


import com.l2fprod.common.demo.TaskPaneMain;
import com.l2fprod.common.swing.JOutlookBar;
import com.l2fprod.common.swing.PercentLayout;
import com.malkit.jmstest.MainPanel;

public class OutlookTypeConfigurationPane extends JPanel {
	private static final long serialVersionUID = 1L;

	List configurationsList = new ArrayList();
	List taskPaneGroupList = new ArrayList();
	Map buttonGroupExtMap = new HashMap();
	
	JOutlookBar outlook = null;
	public OutlookTypeConfigurationPane() {
		
		PercentLayout layout = new PercentLayout(PercentLayout.HORIZONTAL, 0);
		setLayout(layout);
		
		setBorder(BorderFactory.createCompoundBorder(BorderFactory
				.createTitledBorder(""), BorderFactory.createEmptyBorder(0, 0, 0, 0)));

		outlook = new JOutlookBar();
		outlook.setTabPlacement(JTabbedPane.LEFT);
		outlook.setAllTabsAlignment(SwingConstants.CENTER);

		JScrollPane scroll = new JScrollPane(outlook);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.setBorder(null);

		add(scroll, "468");
	}
	
	public void addGroupPanel(Configuration left, Configuration right) {
		configurationsList.add(left);
		configurationsList.add(right);
		
		String label = left.getName() + " | " + right.getName();
		
		String image = null;
		
		String firstType = left.getType();
		String secondType = right.getType();
		
		if(firstType.equals(MainPanel.QUEUE) && secondType.equals(MainPanel.QUEUE)) {
			image = "icons/queue_queue.png";
		} else if (firstType.equals(MainPanel.QUEUE) && secondType.equals(MainPanel.TOPIC)) {
			image = "icons/queue_topic.png";
		} else if (firstType.equals(MainPanel.TOPIC) && secondType.equals(MainPanel.TOPIC)) {
			image = "icons/topic_topic.png";
		} else {
			image = "icons/topic_queue.png";
		}
		
		ImageIcon icon = new ImageIcon(TaskPaneMain.class.getResource(image));
		JPanel mainPane = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.NORTHWEST ;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1;
		c.insets = new Insets(2, 0, 2, 0);
		c.weighty = 0;
		JPanel groupPanel = createInputOutputGroup(left, right);
		mainPane.add(groupPanel, c);
		
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.NONE;
		c.weightx = 0;
		JButton button = getRemoveButton();
		
		mainPane.add(button, c);
		JScrollPane scroll = outlook.makeScrollPane(mainPane);
		outlook.addTab(label, icon, scroll);
		
		JTaskPaneGroupExt groupExt = new JTaskPaneGroupExt(left, right, scroll);
		taskPaneGroupList.add(mainPane);
		buttonGroupExtMap.put(button, groupExt);
		outlook.setEnabledAt(outlook.getSelectedIndex(), true);
		outlook.setSelectedComponent(scroll);
	}

	public List getConfigurationList() {
		return configurationsList;
	}
	
	public void removeTab() {
		outlook.removeTabAt(outlook.getSelectedIndex());
		outlook.revalidate();
		outlook.repaint();
	}
	
	private JButton getRemoveButton() {
		final JButton jbRemove = new JButton();
		jbRemove.setPreferredSize(new Dimension(20,24));
		jbRemove.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/remove.png")));
		jbRemove.setToolTipText("Remove");

		jbRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JTaskPaneGroupExt groupExt = (JTaskPaneGroupExt)buttonGroupExtMap.remove(jbRemove);
				try{
					//outlook.remove(groupExt.getGroup());
					//outlook.remove(jbRemove);
					outlook.removeTabAt(outlook.indexOfComponent(groupExt.getGroup()));
				} catch (Exception e1) {
					
				}
				configurationsList.remove(groupExt.getLeft());
				configurationsList.remove(groupExt.getRight());
				
				taskPaneGroupList.remove(groupExt.getGroup());
				//outlook.setEnabledAt(0, true);
				outlook.revalidate();
				outlook.repaint();
			}
		});
		return jbRemove;
	}

	private void revalidateThis() {
		revalidate();
		repaint();
	}
	
	/**
	 * @param first JMSTestClinet
	 * @param second JMSTestClient
	 * @return JComponent
	 */
	private JPanel createInputOutputGroup(Configuration first, Configuration second) {
		JPanel panel = new JPanel(new GridBagLayout());
		//panel.setPreferredSize(new Dimension(430,150));
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.WEST ;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1;
		c.weighty = 0;
		c.insets = new Insets(2, 0, 2, 0);
		
		panel.add(first.getPropertyPanel(), c);
		panel.add(second.getPropertyPanel(), c);
		
		return panel;
	}
	
	class JTaskPaneGroupExt {
		Configuration left = null;
		Configuration right = null;
		//JTaskPaneGroup group = null;
		JComponent group = null;
		
		//public JTaskPaneGroupExt(Configuration left, Configuration right, JTaskPaneGroup group) {
		public JTaskPaneGroupExt(Configuration left, Configuration right, JComponent group) {
			this.left = left;
			this.right = right;
			this.group = group;
		}

		/*public JTaskPaneGroup getGroup() {
			return group;
		}*/
		public JComponent getGroup() {
			return group;
		}

		public Configuration getLeft() {
			return left;
		}

		public Configuration getRight() {
			return right;
		}
	}
}
