/*
 * BEGIN_HEADER - DO NOT EDIT
 * 
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://open-jbi-components.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://open-jbi-components.dev.java.net/public/CDDLv1.0.html.
 * If applicable add the following below this CDDL HEADER,
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * @(#)XmlInput.java
 *
 * Copyright 2004-2007 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * END_HEADER - DO NOT EDIT
 */

package com.sun.jbi.component.toolkit.project.view.input;

import javax.swing.JOptionPane;
import javax.xml.namespace.QName;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.sun.jbi.common.xml.XmlUtil;
import com.sun.jbi.component.toolkit.project.util.ProjectException;
import com.sun.jbi.component.toolkit.project.util.XPathElement;
import com.sun.jbi.component.toolkit.project.view.App;
import com.sun.jbi.component.toolkit.project.view.BasePanel;

/**
 * 
 * @author Kevan Simpson
 */
public class XmlInput extends BasePanel implements Input {
    private static Element mDefElem;
    
    private QName mCfg;
    private String mTitle;
    
    /**
     * @param app
     * @param params
     */
    public XmlInput(App app, QName cfg, String title) {
        super(app, cfg, title);
    }

    /** @see com.sun.jbi.component.toolkit.project.view.input.Input#prompt(java.lang.String) */
    public Object prompt(String txt) {
        int opt = JOptionPane.showConfirmDialog(null, this, mTitle, 
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (opt == JOptionPane.YES_OPTION) {
            
        }
        return null;
    }

    /** @see com.sun.jbi.component.toolkit.project.view.input.Input#updateItem(com.sun.jbi.component.toolkit.project.util.XPathElement, java.lang.Object) */
    public boolean updateItem(XPathElement item, Object value) {
        // TODO Auto-generated method stub
        return false;
    }

    /** @see com.sun.jbi.component.toolkit.project.view.BasePanel#init(java.lang.Object[]) */
    @Override
    protected void init(Object... params) {
        mCfg = (QName) params[0];
        mTitle = String.valueOf(params[1]);
        
        if (mDefElem == null) {
            try {
                Document doc = XmlUtil.readXml(
                        this.getClass().getResourceAsStream("view-defs.xml"));
                mDefElem = (doc != null) ? doc.getDocumentElement() : null;
            }
            catch (Exception e) {
                throw new ProjectException("Failed to initialize XmlInput with "+ mCfg, e);
            }
        }
        
        
    }
}
