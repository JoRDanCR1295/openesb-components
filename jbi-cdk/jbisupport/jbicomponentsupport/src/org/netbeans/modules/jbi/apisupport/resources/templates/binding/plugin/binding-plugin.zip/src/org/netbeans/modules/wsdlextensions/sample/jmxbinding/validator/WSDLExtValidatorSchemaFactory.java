/*
* WSDLExtValidatorSchemaFactory.java
*/
package org.netbeans.modules.wsdlextensions.sample.jmxbinding.validator;

import java.io.InputStream;
import java.io.InputStream;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import org.netbeans.modules.xml.wsdl.validator.spi.ValidatorSchemaFactory;

/**
 * This class implements ValidatorSchemaFactory interface.
 *
 * @author chikkala
 */
public class WSDLExtValidatorSchemaFactory extends ValidatorSchemaFactory {

    private final String NS_URL = 
        "__WSDL_EXT_NAMESPACE__";
    private final String wsdlExtXSDResourcePath = 
        "__WSDL_EXT_XSD_PATH__";;
    
    public String getNamespaceURI() {
        return NS_URL;
    }
    
    public InputStream getSchemaInputStream() {
        return this.getClass().getResourceAsStream(wsdlExtXSDResourcePath);
    }    
     /**
     * Returns the Inputstream related to this schema
     */
    public Source getSchemaSource() {
        InputStream in = this.getClass().getResourceAsStream(wsdlExtXSDResourcePath);
        Source s = new StreamSource(in);
        s.setSystemId(this.getClass().getResource(wsdlExtXSDResourcePath).toString());
        return s;
    }
    
}
