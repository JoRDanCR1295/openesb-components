/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://open-esb.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://open-esb.dev.java.net/public/CDDLv1.0.html.
 * If applicable add the following below this CDDL HEADER,
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * Copyright 2004-2006 Sun Microsystems, Inc. All Rights Reserved.
 */

/*
 * InOutProviderMessageExchangeHandler.java
 *
 */

package com.sun.jbi.sample.component.runtime;

import javax.jbi.messaging.Fault;
import javax.jbi.messaging.InOut;
import javax.jbi.messaging.MessageExchange;
import javax.jbi.messaging.MessagingException;
import javax.jbi.messaging.NormalizedMessage;

/**
 * This class implements the InOut Message exchange handler implemenation for the
 * Service Provider.
 *
 * It does a synchronous message exchange processing where it invokes the service
 * and wait until the service processes the message and returns the response message.
 * It then return out or fault message to consumer and also waits until the consumer
 * returns the DONE status.
 *
 * Extended class should implement the actual invocation of the service operation by
 * implementing the abstract method invokeInOutOperation of this class.
 *
 * @author Sun Microsystems, Inc.
 */
public abstract class InOutProviderMessageExchangeHandler extends AbstractMessageExchangeHandler {
    
    public static final long SEND_SYNC_TIMEOUT = 60000;
    
    /** Creates a new instance of InOutProviderMessageExchangeHandler */
    public InOutProviderMessageExchangeHandler() {
        super();
    }
    
    protected void validateMessageExchange() throws MessagingException {
        
        MessageExchange msgExchange = this.getMessageExchange();
        
        if ( this.getMessageExchange() == null ) {
            throw new MessagingException("MessageExchange Object is null in MessageExchageHandler");
        }
        
        if ( MessageExchange.Role.CONSUMER.equals(msgExchange.getRole()) ) {
            throw new MessagingException("Provider Message Exchange Handler can not have MessageExchange with CONSUMER Role");
        }
        
        if (!(msgExchange instanceof InOut) ) {
            throw new MessagingException("InOut Message Exchange Handler MessageExchange object should be instanceof javax.jbi.messaging.InOut ");
        }
    }
    
    protected void processFault(Fault fault) {
        RuntimeHelper.logError("InOut Message Exchange Provider Handler can not receive Fault on Provider side");
    }
    
    protected void processDone() {
        RuntimeHelper.logVerbose("InOut Message Exchange Provider handler received DONE : END of service invocation");
    }
    
    protected void processError(Exception ex) {
        RuntimeHelper.logError("InOut Message Exchange Provider handler received Error");
        RuntimeHelper.logError(ex);
    }
    
    protected final void processMessage() {
        
        InOut inOutMX = (InOut) this.getMessageExchange();
        
        NormalizedMessage inMsg = inOutMX.getInMessage();
        if ( inMsg == null ) {
            this.sendError(new MessagingException("InOut Provider MessageExchange received null In Message"));
            return;
        }
        
        handleInMessage(inMsg);
    }
    
    private void handleInMessage(NormalizedMessage inMsg) {
        
        Fault fault = null;
        Exception processingEx = null;
        NormalizedMessage outMsg = null;
        boolean result = false;
        
        InOut inOutExchange = (InOut) this.getMessageExchange();
        try {
            // create out and fault messages
            outMsg = inOutExchange.createMessage();
            fault = inOutExchange.createFault();
            // invoke operation
            result = invokeOperation(inMsg, outMsg, fault);
        } catch (Exception ex) {
            processingEx = ex;
            ex.printStackTrace();
        } finally {
            try {
                if ( result == true ) {
                    // operation success
                    this.sendOutMessage(outMsg);
                } else {
                    // operation failed or some exception happened.
                    if ( processingEx != null ) {
                        // set fault content with exception msg
                        this.sendFault(processingEx);
                    } else {
                        // fault content has been set by the operation.
                        this.sendFault(fault);
                    }
                }
            } catch (MessagingException ex) {
                ex.printStackTrace();
                this.sendError(ex);
                return;
            }
        }
        // process the message exchange again after sending the fault or out message to
        // process the done or error received.
        this.processMessageExchange();
    }
    
    public void sendFault(Fault fault) throws MessagingException {
        InOut inOutMX = (InOut) this.getMessageExchange();
        inOutMX.setFault(fault);
        boolean sent = false;
        try {
            sent = this.getDeliveryChannel().sendSync(inOutMX, SEND_SYNC_TIMEOUT);
            if (!sent) {
                inOutMX.setError(new MessagingException("InOutProvider ME Handler unable to send out message"));
            }
        } catch (Exception ex) {
            inOutMX.setError(ex);
        }
    }
    
    private void sendOutMessage(NormalizedMessage outMsg) throws MessagingException {
        
        InOut inOutMX = (InOut) this.getMessageExchange();
        inOutMX.setOutMessage(outMsg);
        boolean sent = false;
        try {
            sent = this.getDeliveryChannel().sendSync(inOutMX, SEND_SYNC_TIMEOUT);
            if (!sent) {
                inOutMX.setError(new MessagingException("InOutProvider ME Handler unable to send out message"));
            }
        } catch (Exception ex) {
            inOutMX.setError(ex);
        }
    }
    
    protected abstract boolean invokeOperation(NormalizedMessage inMsg, NormalizedMessage outMsg, Fault fault) throws MessagingException;
    
}
