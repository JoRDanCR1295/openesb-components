/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://open-esb.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://open-esb.dev.java.net/public/CDDLv1.0.html.
 * If applicable add the following below this CDDL HEADER,
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * Copyright 2004-2006 Sun Microsystems, Inc. All Rights Reserved.
 */

/*
 * BindingComponentTest.java
 *
 */

package bindingtest;

import com.sun.jbi.sample.test.JMXBindingTestClient;
import com.sun.jbi.sample.test.JBIComponentTestClient;
import java.util.Properties;
import junit.framework.TestCase;

/**
 * This is the unit test case for testing the sample JMXBinding component generated
 * by the binding component project wizard. The test method in this testcase uses
 * the JMXBindingTestClient to send the input document to the JMXBinding to invoke
 * a service on the sample ServiceEngine and receives the output document which will
 * be placed in junit results directory under the same package as this test case.
 *
 * @author Sun Microsystems, Inc.
 */
public class BindingComponentTest extends TestCase {
    
    public BindingComponentTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testBindingComponent() throws Exception {
                
        JMXBindingTestClient testClient = new JMXBindingTestClient();
        Properties testProps = testClient.loadTestProperties(this.getClass());
        testClient.testService(testProps);
    }
    
}
